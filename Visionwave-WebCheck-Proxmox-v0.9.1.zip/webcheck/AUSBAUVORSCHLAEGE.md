# Qualitätschecks und nächste Ausbaustufen

Diese Prüfbereiche sind seit Version 0.7.0 als begrenzte automatische Teilprüfungen umgesetzt. Der aktuelle tatsächliche Umfang steht in README.md. Die Tabelle beschreibt zusätzlich mögliche Vertiefungen, insbesondere echte Nutzerdaten und fachliche bzw. kontrollierte Prozessprüfungen.

| Priorität | Prüfung | Mehrwert für Kunden | Umfang |
| --- | --- | --- | --- |
| 1 | Ladegeschwindigkeit | Langsame Seiten, große Bilder und Layoutsprünge erkennen; konkrete Optimierungsmaßnahmen | Orientierender separater Performance-Labortest mit Wiederholungen; die sichere Anfragevermittlung beeinflusst Messwerte. Optional echte Nutzerdaten aus CrUX; eine einzelne Labormessung ersetzt keine Bewertung realer Core Web Vitals. |
| 1 | Defekte Links und Weiterleitungen | Sackgassen und unerreichbare Kontakt-/Angebotsseiten beheben | Begrenzter Linkcheck mit DNS-/SSRF-Schutz, Statuscodes, internen Ankern und Redirectketten. |
| 1 | SEO-Grundlagen | Hindernisse für Auffindbarkeit sichtbar machen | Titel, Beschreibungen, Canonical, robots/noindex, Sitemap und strukturierte Daten; keine Rankinggarantie. |
| 2 | Technische Sicherheitsbasis | Konfigurationsprobleme und unsichere Einbindungen erkennen | HTTPS, Zertifikat, Mixed Content und kontextbezogene Header-Prüfung (CSP, HSTS, Referrer-Policy). Kein Penetrationstest. |
| 2 | Erweiterter Cookie-/Tracking-Test | Zeigen, ob Dienste nach Ablehnung, Auswahl oder Widerruf weiter aktiv sind | Mehrstufige Banner, Wiederbesuch, verzögerte Requests und Consent-Zustände; rechtliche Bewertung separat. |
| 2 | Kontakt- und Anfrageformulare | Verlorene Anfragen und Bedienprobleme aufdecken | Pflichtfelder, verständliche Fehlermeldungen und Tastaturbedienung automatisch. Tatsächliche Zustellung derzeit als ergänzender fachlicher Test; kein Versand durch diese Version. |
| 3 | Dokumente und Multimedia | Barrierefreiheit über die HTML-Seiten hinaus verbessern | PDF-Struktur, Dokumenttitel, Sprache sowie Untertitel-/Transkripthinweise. Lesereihenfolge und Qualität ergänzend manuell prüfen. |

Umgesetzt als Berichtsfunktion: Vorher-/Nachher-Vergleich nach einer Optimierung, mit identischem Prüfumfang und gleicher Prüfversion, Datum und Kennzeichnung nicht vergleichbarer Messungen. Erledigte Befunde und verbleibende Aufgaben transparent darstellen. Daraus kann eine regelmäßige Wartungsprüfung entstehen.

Fachliche Quellen:
- Core Web Vitals: https://web.dev/articles/defining-core-web-vitals-thresholds
- Google Crawling und Indexierung: https://developers.google.com/search/docs/crawling-indexing
- HTTP-Header: https://developer.mozilla.org/en-US/docs/Web/HTTP/Reference/Headers
