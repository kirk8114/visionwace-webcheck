# Visionwave Media WebCheck 0.9.1 – Lokal- und Proxmox-Version

## Neu: Proxmox-/Docker-Serverinstallation

Die vollständige Anleitung steht in [deploy/PROXMOX.md](deploy/PROXMOX.md).
Empfohlen: Debian-13-VM, 2 Kerne, 4 GB RAM, 32 GB Speicher. Docker-Installer,
WebCheck-Installer, Anmeldung, dauerhaftes Berichtsvolume, Sicherung und
Update-/Rollback-Befehle sind enthalten. Für Updates aus ChatGPT ist ein
GitHub-Workflow vorbereitet; privates Repository und VM-Runner müssen einmalig
verbunden werden. Ohne diese Einrichtung besteht noch kein Serverzugriff.
Der bisherige lokale Windows-Start bleibt verfügbar.


Website-Prüfassistent für Impressum, DSGVO/TDDDG, WCAG und BFSG. Automatische Teilprüfungen und geführte manuelle Checklisten; keine Zertifizierung und keine vollständige rechtliche Konformitätsprüfung.

## Windows: schnell starten

1. ZIP vollständig entpacken (nicht direkt aus dem ZIP starten).
2. Node.js 22 oder 24 LTS von https://nodejs.org installieren.
3. `Start-Windows.cmd` doppelklicken. Beim ersten Start werden npm-Pakete und Chromium heruntergeladen. Internetzugang erforderlich.
4. Falls der Browser zu früh öffnet: http://localhost:3000 nach einigen Sekunden neu laden.
5. Website eingeben, Berechtigung bestätigen, Prüfung starten.
6. Das Konsolenfenster geöffnet lassen. Stoppen mit Strg+C.

Alternative ohne lokale Node.js-Installation: Docker Desktop starten und `Start-Docker.cmd` ausführen.

## Linux / macOS mit Node.js

```sh
npm ci
npx playwright install chromium
npm start
```

Unter Linux gegebenenfalls vorher `npx playwright install --with-deps chromium` ausführen (benötigt für Systempakete eventuell Administratorrechte). Browser: http://localhost:3000.

## Docker auf dem späteren Server

Docker Engine mit Compose installieren, Projektordner kopieren, dann:

```sh
docker compose up -d --build
docker compose logs -f
docker compose down
```

Port 3000 ist absichtlich nur an 127.0.0.1 gebunden. Zugriff von deinem PC über einen SSH-Tunnel:

```sh
ssh -L 3000:127.0.0.1:3000 benutzer@server
```

Dann http://localhost:3000 auf deinem PC öffnen. Das Named Volume `webcheck-data` speichert Berichte dauerhaft. `docker compose down` erhält die Daten; `docker compose down -v` löscht sie.

Die Version ist eine lokale Einzelbenutzeranwendung ohne Benutzerverwaltung. Nicht durch Änderung der Portbindung öffentlich zugänglich machen. Ein späterer öffentlicher Dienst braucht Authentifizierung, Mandantentrennung, verbindliche Aufbewahrungsregeln und gehärteten Scanbetrieb. Eigene Domain-/Proxy-Hosts werden derzeit bewusst abgewiesen.

## Funktionen

- Bis zu 10 öffentliche Seiten derselben Origin; Links ohne Querystring, keine Loginprüfung.
- Browserbasierte WCAG 2.2 A/AA-Teilprüfung mit axe-core. Technische Mängel und nicht abschließend bewertbare Regeln bleiben getrennt.
- Frische isolierte Browserkontexte für Ausgangszustand, Ablehnung und Zustimmung.
- Erkennung ausgewählter Dienste: Google Analytics, Google Ads, Tag Manager, Meta Pixel, Fonts, YouTube, Maps, reCAPTCHA, Vimeo, Hotjar, Clarity, TikTok.
- Cookie-Metadaten und Local-/Session-Storage-Schlüssel; keine Cookie-Werte im Bericht.
- Screenshots, Ladefehler, blockierte Requests und Prüfversion als Belege.
- BFSG-Anwendungsbereich als vorläufige Einordnung anhand Betreiberangaben, keine automatisierte Rechtsentscheidung.
- Impressum und Datenschutzerklärung: Links, untersuchte Dokumente, erkennbare Pflichtangaben und Abgleich benannter externer Dienste.
- 12 geführte fachliche Fragen, jeweils mit automatischem Prüfversuch und ausdrücklicher Kennzeichnung offener Nachweise.
- Gespeicherte Berichte, Maßnahmenhinweise, JSON-/CSV-Export, Drucken → als PDF speichern.

## Bewusste Grenzen

POST/PUT/DELETE-Anfragen der Zielseiten sind gesperrt. Das verhindert Formularübermittlungen, beschränkt aber Consent- und dynamische Dienste. Auch GET-Aufrufe können bei falsch gestalteten Zielseiten Wirkungen haben: nur berechtigt und vorzugsweise auf Testseiten prüfen.

Cookie-Schaltflächen und Einstellungsdialoge werden anhand eindeutiger Beschriftungen versucht. Wiederbesuch und Widerruf über erneutes Öffnen und Ablehnung werden getestet, wenn Bedienmöglichkeiten erkannt werden. Granulare Kategorien und serverseitige Einwilligungsnachweise bleiben fachlich offen. „Schaltfläche betätigt“ bedeutet nicht, dass eine Einwilligung wirksam gespeichert wurde. Dienste werden über Request-URLs erkannt; unbekannte, eigene oder serverseitige Tracker können unerkannt bleiben. Erfasst werden frühe Seitenzustände nach kurzer Wartezeit, keine langfristige Verhaltensbeobachtung.

Keine vollständige Prüfung von Datenschutzerklärungen, Rechtsgrundlagen, Verträgen, Screenreader-Nutzung, Checkout, PDF-Dateien oder mobilen Seiten. BFSG-Anforderungen sind separat fachlich zu bewerten; WCAG 2.2 ist das technische Prüfprofil und kein alleiniger BFSG-Nachweis.

Nur Standardports 80/443, keine privaten/lokalen/reservierten Ziele. DNS-Adressen werden vor jeder Anfrage geprüft und für den tatsächlichen HTTP-Aufruf fest gebunden. WebSockets und Service Worker sind deaktiviert. Antwortlimit 8 MB, Requestlimit 1200 pro Scan, maximal 6 Minuten. Blockierte Ressourcen und Zeitlimits können zu unvollständigen Ergebnissen führen. Ein Scan ohne erkannte Mängel bedeutet nicht „konform“.

Lokale Daten liegen im Ordner `data/`, im Container unter `/app/data`. Screenshots und Request-Pfade können personenbezogene Inhalte enthalten; Berichte bei Bedarf löschen und Zugriffsrechte des Ordners beachten. Keine Cloud-KI und keine externen ChatGPT-Plugins zur Laufzeit erforderlich. Die besuchten Websites und ihre externen Ressourcen werden beim Scan tatsächlich aufgerufen.

## Tests

```sh
npm ci
npx playwright install chromium
npm test
```

Die Tests umfassen URL-/DNS-Sperren, lokale API, Cross-Origin-Schutz, eine gezielte Browser-Testseite mit WCAG-Fehlern und isolierten Cookie-Zuständen sowie Desktop/Mobil-Darstellung der Oberfläche. Eine localhost-Ausnahme existiert nur als interner Testparameter und wird nicht über die API angeboten.

Siehe `TESTBERICHT.md` für tatsächlich hier ausgeführte Prüfungen. Docker-Start und Installation auf einem Windows-Gerät müssen auf deinem System getestet werden.

## Fachliche Grundlagen

- W3C WCAG 2.2: https://www.w3.org/TR/WCAG22/
- W3C Evaluierung: https://www.w3.org/WAI/test-evaluate/
- TDDDG § 25: https://www.gesetze-im-internet.de/ttdsg/__25.html
- BFSG: https://www.gesetze-im-internet.de/bfsg/
- BFSGV: https://www.gesetze-im-internet.de/bfsgv/
- DDG § 5 (Impressum): https://www.gesetze-im-internet.de/ddg/__5.html
- DSGVO Art. 13: https://eur-lex.europa.eu/eli/reg/2016/679/oj

Technische Regeln und rechtliche Zuordnungen vor produktiver Nutzung aktuell fachlich überprüfen. Prüfberichte dokumentieren die Version `2026-10-08 / Version 0.8.5`.

## Kundenbericht auf Firmenpapier

Im gespeicherten Bericht **Kundenbericht auf Firmenpapier als PDF** öffnen, Kunde, Projekt, Titel und Anmerkungen eintragen und **Kunden-PDF herunterladen** wählen. Geänderte fachliche Antworten vorher speichern.

Das originale Visionwave-Firmenpapier wird als Hintergrund verwendet; der Berichtstext bleibt auswählbar. Ein gestaltetes Titelblatt und ein anklickbares Inhaltsverzeichnis eröffnen den Bericht. Danach folgen die Ampelübersicht und Statistiken für untersuchte Seiten, Einzelbefunde, zusammengefasste Themen und Bearbeitungsprioritäten. Danach folgen verständliche Erläuterungen und eigene Kapitel für Impressum, Datenschutz, WCAG und BFSG mit Verbesserungsvorschlägen ohne Codeauszüge. Kapitel und Befunde werden nach Bearbeitungsbedarf sortiert. Automatische Prüfversuche und ergänzende Antworten stehen im passenden Kapitel. Das Inhaltsverzeichnis zeigt tatsächliche Seitenzahlen, auch bei langen Berichten. Befunde werden nach Schweregrad sortiert, ähnliche Befunde zusammengefasst und mit ROT/GELB in der Überschrift markiert. Die Zahlen sind keine prozentuale Konformitätsbewertung. Prioritäten beschreiben den technischen Bearbeitungsbedarf, keine verbindliche rechtliche Risikobewertung.

Rot steht für erkannte Mängel bzw. dokumentierten Handlungsbedarf, Gelb für Verdacht und offene Klärungen. Grün ist nur innerhalb des dokumentierten Prüfumfangs und bei ausreichenden ergänzenden Angaben möglich. Fehlende Nachweise ergeben kein automatisches Grün.

Im Ordner `beispiel/` liegt ein fiktiver Beispielbericht mit Titelblatt und Kategorien. Die erzeugten PDFs sind nicht als PDF/UA zertifiziert. Das Briefpapier wird mitgeliefert; ein Upload in der Oberfläche ist derzeit nicht vorgesehen.

## Automatische fachliche Prüfversuche

Jeder der 12 Auswahlpunkte erhält einen Prüfversuch. Textsignale, rechtliche Dokumente, 30 Tab-Schritte, der zugängliche Browser-Inhaltsbaum und die mobile Darstellung bei 320 Pixel Breite werden untersucht. Mobile axe-Mängel erscheinen ebenfalls als Befunde.

Diese Versuche ersetzen keine fachliche Bewertung und setzen die Ja/Nein-Antworten nicht automatisch. Textsignale beweisen keine Anwendbarkeit oder Konformität. Ein fokussiertes Element beweist keinen sichtbaren Fokusrahmen; ein Browser-Inhaltsbaum ersetzt keinen echten Screenreader-Test. Beschäftigtenzahl, Finanzkennzahlen und tatsächliche Verträge bleiben ohne Nachweise offen.

Google-Dienste werden einzeln unterschieden; Google Tag Manager allein wird nicht als Beweis für Tracking gewertet. Fehlende Angaben in Rechtsdokumenten und mögliche Abweichungen zwischen erkannten Diensten und Datenschutzerklärung werden als Verdacht ausgewiesen.

## Update installieren und Berichte behalten

Anwendung mit Strg+C beenden. Neues ZIP vollständig entpacken. Den bisherigen Ordner `data/` in den neuen WebCheck-Ordner kopieren und `Start-Windows.cmd` starten. Unter http://localhost:3000/api/health muss `0.8.5` stehen. Für die neuen Prüfungen Websites erneut scannen. Frühere GoBD-Befunde werden in alten Berichten und Exporten ausgeblendet; GoBD gehört nicht mehr zum Prüfumfang.

Docker-Nutzer bauen mit `docker compose up -d --build` neu. Für die Übernahme des bisherigen Volumes den gleichen Compose-Projektnamen verwenden.

## Neu in 0.8.5: zusätzliche Qualitätschecks

- Performance: zwei frische Browser-Labordurchläufe der Startseite; orientierende LCP-, Layoutverschiebungs-, Datenmengen- und Request-Messwerte. Die Anfragevermittlung des abgesicherten Scanners beeinflusst die Messung. Kein echter INP-/CrUX-Nachweis. Unvollständige Durchläufe werden nicht positiv bewertet.
- SEO: Titel, Beschreibung, Hauptüberschrift, noindex-Anweisungen, Canonical, JSON-Lesbarkeit strukturierter Daten, robots.txt und sitemap.xml an Standardadressen. Keine vollständige Schema-Validierung und keine Rankinggarantie.
- Links: bis zu 40 geeignete interne Ziele, HTTP-Fehlercodes, maximal fünf Weiterleitungen und Sprungmarken. Externe Ziele, Querystrings und mögliche Aktionslinks werden ausgelassen.
- Sicherheit: HTTP/HTTPS, erkannte Zertifikatslaufzeit, unsichere Ressourcen und ausgewählte Sicherheitsheader. Fehlende Header sind Konfigurationshinweise; kein Penetrationstest.
- Formulare: Pflichtfelder, Beschriftungen, Eingabetypen, Zieladressen und ungültige Testwerte in isolierten Feldkopien. Keine Formulare werden versendet; tatsächliche Fehlermeldungen, Verarbeitung und Zustellung bleiben fachliche Tests.
- Dokumente und Multimedia: bis zu fünf gefundene PDF-Dateien im Linkprüfumfang unter 8 MB, Dokumenttitel, Sprache und Strukturkennzeichnung. Untertitel-Tracks, Transkripthinweise, native Bedienelemente und externe Player werden gesucht. Qualität und vollständige Zugänglichkeit bleiben offen.
- Cookie-Tests: Einstellungsdialog, Wiederbesuch nach Ablehnung/Zustimmung und Widerrufsversuch bei eindeutig erkannten Schaltflächen. Nicht erkannte Abläufe werden ausdrücklich als offen ausgewiesen.
- Vorher/Nachher: automatischer Vergleich mit dem jüngsten gespeicherten Bericht derselben Website, nur bei gleicher Prüfversion und gleichen untersuchten Seiten ohne Ladefehler oder blockierte Ressourcen. Neue, erneut erkannte und nicht mehr erkannte Befunde werden getrennt ausgewiesen. Nicht mehr erkannt bedeutet nicht nachweislich behoben.

Alle Zusatzchecks erscheinen in der Oberfläche und in eigenen Kundenbericht-Kapiteln. Logo und Anschrift stehen nur auf dem Titelblatt; farbige Gestaltung und Fußzeile bleiben auf den Inhaltsseiten. Inhaltsverzeichnis und Seitenzahlen passen sich automatisch an.

Für die neuen Checks ist ein neuer Scan nötig. Alte Berichte werden nicht nachträglich mit Messwerten ergänzt. Ein vergleichbarer Vorgänger entsteht nach mindestens zwei Scans mit Version 0.8.5 und identischem Umfang.

## Berichtsgestaltung 0.8.5

Typografisches Titelblatt, keine doppelte Kapitelüberschrift auf Kapitelanfangsseiten, größere Abschnittsabstände und mehr Abstand unter Statistik-Kacheln. Statusfarben bleiben erhalten; Farbwörter entfallen an einzelnen Befunden und Bereichsstatus. Priorisierte Handlungsempfehlungen und konkrete Maßnahmen pro Befund werden ausgegeben.

Fehlgeschlagene bzw. nicht ausgeführte Checks werden nur im Kunden-PDF ausgeblendet, einschließlich nicht messbarer Performance und gescheiterter PDF-/Link-Prüfversuche. Die technische Ansicht und gespeicherten Daten behalten diese Informationen. Tatsächlich negative Ergebnisse wie HTTP 404 bleiben sichtbar. Ausgeblendete oder unbekannte Prüfungen werden nicht als bestanden gewertet; der allgemeine Prüfumfang bleibt benannt.

## Performance-Tabelle 0.8.5

Kunden-PDF mit Soll-/Ist-Tabelle: LCP, CLS, Datenmenge, Dokumentaufbau und Anfragezahl, sofern verfügbar. LCP/CLS-Zielwerte nach web.dev (2,5 Sekunden und 0,1); Datenmenge 2 MiB als ausdrücklich benannter Agentur-Richtwert. Dokumentaufbau und Anfragezahl haben individuelle Ziele, keine erfundenen Standardgrenzen. Labormessungen ersetzen keine Bewertung realer Nutzerdaten.

## Titelblatt 0.8.5

Vergrößertes originales Firmenlogo mittig unter den oberen Gestaltungswellen. Persönlicher Name, Firmenanschrift, Telefon und E-Mail entfallen im PDF. Kundendaten und Projektdaten bleiben erhalten. Inhaltsseiten weiterhin ohne Logo und Anschrift.

## Kundenbericht 0.8.5

Allgemeine Ampelkommentare über unvollständige Antworten und pauschale fachliche Bestätigungen entfallen unter den einzelnen Bereichsstatus. Farbliche Einordnung, konkrete Befunde, Handlungsempfehlungen und die einmalige Beschreibung des Prüfumfangs bleiben erhalten.

## Titelblatt 0.8.5

Textblock automatisch vertikal zwischen Firmenlogo und durchgehender Linie zentriert, einschließlich variabler Titel-/Kunden-/Projektzeilen.

## Proxmox-Schnellinstallation 0.9.1

`proxmox-install.sh` erstellt einen neuen Debian-13-LXC und installiert WebCheck. Anleitung: [PROXMOX-SCHNELLSTART.md](PROXMOX-SCHNELLSTART.md). Auf dem Proxmox-Host starten; VM-Installation bleibt alternativ verfügbar. Kein öffentlicher Download-Einzeiler eingerichtet.
