#!/usr/bin/env bash
set -Eeuo pipefail
BASE=/opt/visionwave-webcheck
cd "$BASE"
[[ -f config.env ]] || { echo 'Zuerst install.sh ausführen.'; exit 1; }
exec 9>"$BASE/deploy.lock"
flock -n 9 || { echo 'Ein anderer Verwaltungsvorgang läuft.'; exit 1; }
compose(){ docker compose --env-file "$BASE/config.env" --env-file "$BASE/image.env" -f "$BASE/compose.yaml" "$@"; }
health(){ compose exec -T webcheck node -e "fetch('http://localhost:3000/api/health').then(async r=>{if(!r.ok)process.exit(1);const h=await r.json();console.log(JSON.stringify(h));if(process.argv[1]==='idle'&&h.active)process.exit(2)}).catch(()=>process.exit(1))" "${1:-status}"; }
wait_ready(){ for attempt in {1..30}; do if health >/dev/null 2>&1; then return 0; fi; sleep 2; done; return 1; }
backup(){
 mkdir -p "$BASE/backups"
 local out="$BASE/backups/reports-$(date -u +%Y%m%dT%H%M%SZ)-$$.tar.gz"
 docker run --rm --network none --user 0 --entrypoint tar -v visionwave-webcheck-data:/data:ro "$CURRENT" -czf - -C /data . > "$out"
 chmod 600 "$out"
 echo "Datensicherung: $out"
}
CURRENT=''
if [[ -f image.env ]]; then CURRENT=$(sed -n 's/^WEBCHECK_IMAGE=//p' image.env); fi
case "${1:-help}" in
 status) compose ps; health ;;
 logs) compose logs --tail 100 ;;
 backup)
  health idle >/dev/null || { echo 'Dienst nicht bereit oder Scan aktiv. Später erneut versuchen.'; exit 1; }
  compose stop -t 30 webcheck
  trap 'compose start webcheck >/dev/null' EXIT
  backup
  ;;
 rollback)
  [[ -s previous-image.env ]] || { echo 'Keine vorherige Version vorhanden.'; exit 1; }
  health idle >/dev/null || { echo 'Dienst nicht bereit oder Scan aktiv.'; exit 1; }
  cp image.env rollback-current.env
  cp previous-image.env image.env
  if compose up -d --no-build --wait --wait-timeout 90; then mv rollback-current.env previous-image.env; health; else mv rollback-current.env image.env; compose up -d --no-build; exit 1; fi
  ;;
 update)
  SOURCE=$(realpath "${2:?Pfad zum entpackten webcheck-Ordner fehlt}")
  VERSION=$(python3 - "$SOURCE" <<'PY'
import json,sys,re,pathlib
p=pathlib.Path(sys.argv[1])
for name in ['Dockerfile','package.json','package-lock.json','src/server.js','public/index.html','assets/letterhead.png']:
 if not (p/name).is_file():raise SystemExit('Unvollständiges Paket: '+name)
for folder in ['src','public','assets']:
 if any(x.is_symlink() for x in (p/folder).rglob('*')):raise SystemExit('Symlinks im Paket sind nicht erlaubt.')
v=json.loads((p/'package.json').read_text())['version']
if not re.fullmatch(r'\d+\.\d+\.\d+',v):raise SystemExit('Ungültige Versionsnummer')
print(v)
PY
)
  STAGE=$(mktemp -d "$BASE/release.XXXXXX")
  cp "$SOURCE/Dockerfile" "$SOURCE/package.json" "$SOURCE/package-lock.json" "$STAGE/"
  cp -r "$SOURCE/src" "$SOURCE/public" "$SOURCE/assets" "$STAGE/"
  NEXT="visionwave-webcheck:$VERSION-$(date -u +%Y%m%d%H%M%S)-$$"
  # Image vollständig bauen, bevor der laufende Dienst berührt wird.
  docker build -t "$NEXT" "$STAGE"
  rm -rf "$STAGE"
  if [[ -n "$CURRENT" ]]; then
   health idle >/dev/null || { echo 'Dienst nicht bereit oder Scan aktiv. Update später erneut versuchen.'; exit 1; }
   cp image.env previous-image.env
   compose stop -t 30 webcheck
   trap 'cp "$BASE/previous-image.env" "$BASE/image.env"; compose up -d --no-build >/dev/null' ERR
   backup
  fi
  printf 'WEBCHECK_IMAGE=%s\n' "$NEXT" > image.env
  chmod 600 image.env
  if compose up -d --no-build --wait --wait-timeout 90 && wait_ready; then
   trap - ERR
   health
   echo "Version $VERSION installiert."
  else
   trap - ERR
   if [[ -n "$CURRENT" ]]; then cp previous-image.env image.env; compose up -d --no-build; echo 'Startprüfung fehlgeschlagen. Vorherige Version wieder aktiviert.'; fi
   exit 1
  fi
  ;;
 *) echo 'Verwendung: manage.sh status | logs | backup | update /pfad/webcheck | rollback' ;;
esac
