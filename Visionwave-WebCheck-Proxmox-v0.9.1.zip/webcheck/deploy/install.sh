#!/usr/bin/env bash
set -Eeuo pipefail
[[ $EUID == 0 ]] || { echo 'Mit sudo starten.'; exit 1; }
command -v python3 >/dev/null
command -v docker >/dev/null
docker compose version >/dev/null
SOURCE=$(cd "$(dirname "$0")/.." && pwd)
BASE=/opt/visionwave-webcheck
[[ ! -e "$BASE/config.env" ]] || { echo 'Bereits installiert. Für Updates manage.sh update verwenden.'; exit 1; }
if [[ -z ${WEBCHECK_INSTALL_ADDRESS:-} ]]; then read -r -p 'VM-/Container-IP oder DNS-Name: ' ADDRESS; else ADDRESS=$WEBCHECK_INSTALL_ADDRESS; fi
if [[ -z ${WEBCHECK_INSTALL_USER:-} ]]; then read -r -p 'Anmeld Benutzer [admin]: ' USERNAME; else USERNAME=$WEBCHECK_INSTALL_USER; fi
USERNAME=${USERNAME:-admin}
[[ "$ADDRESS" =~ ^[a-zA-Z0-9.-]+$ && "$USERNAME" =~ ^[a-zA-Z0-9_-]+$ ]] || { echo 'Ungültige Eingabe.'; exit 1; }
install -d -m 700 "$BASE" "$BASE/backups"
install -m 700 "$SOURCE/deploy/manage.sh" "$BASE/manage.sh"
install -m 600 "$SOURCE/deploy/compose.server.yaml" "$BASE/compose.yaml"
PASSWORD=$(python3 -c 'import secrets;print(secrets.token_hex(24))')
printf 'WEBCHECK_BIND_IP=0.0.0.0\nWEBCHECK_PORT=3000\nWEBCHECK_ORIGIN=http://%s:3000\nWEBCHECK_USER=%s\nWEBCHECK_PASSWORD=%s\n' "$ADDRESS" "$USERNAME" "$PASSWORD" > "$BASE/config.env"
chmod 600 "$BASE/config.env"
"$BASE/manage.sh" update "$SOURCE"
echo "WebCheck: http://$ADDRESS:3000"
echo "Benutzer: $USERNAME"
echo "Passwort: $PASSWORD"
echo 'Zugangsdaten speichern. HTTP nur im vertrauenswürdigen LAN/VPN; für Internetzugang HTTPS-Reverse-Proxy verwenden.'
