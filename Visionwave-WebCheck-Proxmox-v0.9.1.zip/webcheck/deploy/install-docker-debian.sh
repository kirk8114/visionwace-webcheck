#!/usr/bin/env bash
set -Eeuo pipefail
[[ $EUID == 0 ]] || { echo 'Mit sudo starten.'; exit 1; }
source /etc/os-release
[[ $ID == debian && $VERSION_ID =~ ^(12|13)$ ]] || { echo 'Benötigt Debian 12 oder 13 in einer eigenen VM.'; exit 1; }
[[ $(dpkg --print-architecture) == amd64 ]] || { echo 'Dieses Paket ist für x86_64/amd64 vorgesehen.'; exit 1; }
if command -v docker >/dev/null; then docker compose version; exit; fi
for package in docker.io podman-docker containerd runc; do
 if dpkg-query -W -f='${Status}' "$package" 2>/dev/null | grep -q 'install ok installed'; then echo "Vorhandenes Paket $package: Docker bitte manuell einrichten; keine bestehende Installation wird entfernt."; exit 1; fi
done
apt-get update
apt-get install -y ca-certificates curl python3 unzip
install -m 0755 -d /etc/apt/keyrings
curl -fsSL https://download.docker.com/linux/debian/gpg -o /etc/apt/keyrings/docker.asc
chmod a+r /etc/apt/keyrings/docker.asc
cat > /etc/apt/sources.list.d/docker.sources <<SOURCES
Types: deb
URIs: https://download.docker.com/linux/debian
Suites: ${VERSION_CODENAME}
Components: stable
Architectures: amd64
Signed-By: /etc/apt/keyrings/docker.asc
SOURCES
apt-get update
apt-get install -y docker-ce docker-ce-cli containerd.io docker-buildx-plugin docker-compose-plugin
systemctl enable --now docker
docker compose version
