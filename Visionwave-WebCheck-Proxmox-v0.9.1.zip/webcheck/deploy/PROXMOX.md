# Visionwave WebCheck 0.9.0 auf Proxmox

## Empfohlene Installation

Eine eigene **Debian 13 VM (amd64)** mit **2 CPU-Kernen, 4 GB RAM und 32 GB Festplatte** anlegen. WebCheck läuft darin als Docker-Container. Die VM bekommt eine feste IP oder eine DHCP-Reservierung. In Proxmox „Beim Booten starten“ aktivieren. Netzwerkzugriff auf die zu prüfenden öffentlichen Websites sowie Docker/Microsoft-Registries muss möglich sein.

Dieses Paket erzeugt keine VM automatisch und ist kein OVA-Image. Es enthält die Anwendung, Docker-Konfiguration und Installationsskripte. Docker direkt auf dem Proxmox-Host wird nicht benötigt. Ein LXC ist optional möglich, aber verschachtelter Docker-/Browserbetrieb wurde nicht getestet; deshalb ist die VM der Standardweg.

### 1. Paket übertragen

ZIP auf dem PC entpacken. Den vollständigen Ordner `webcheck` beispielsweise mit WinSCP nach `/tmp/webcheck` auf die VM kopieren. Per SSH anmelden. Die folgenden Befehle in der **Debian-VM**, nicht auf dem Proxmox-Host, ausführen:

```bash
cd /tmp/webcheck
sudo bash deploy/install-docker-debian.sh
sudo bash deploy/install.sh
```

Der Installer fragt VM-IP/DNS-Name und Benutzer ab, erzeugt ein langes zufälliges Passwort und zeigt URL und Zugangsdaten an. Zugangsdaten sicher speichern. Der erste Build lädt das Playwright-Browserimage und kann mehrere Minuten dauern. Bei abgebrochenem Erststart:

```bash
sudo /opt/visionwave-webcheck/manage.sh update /tmp/webcheck
```

### 2. Benutzen

Im Browser `http://VM-IP:3000` öffnen und anmelden. Der Benutzername ist standardmäßig `admin`; das Passwort stammt vom Installer. Nach dem Booten starten VM und Container automatisch, wenn Proxmox-Autostart aktiviert ist.

Serverkonfiguration: `/opt/visionwave-webcheck/config.env` (nur für den Administrator lesbar). Bind-Adresse, Port, erwarteter Browser-Ursprung und Zugangsdaten stehen dort. Nach Änderungen:

```bash
sudo /opt/visionwave-webcheck/manage.sh update /tmp/webcheck
```

`WEBCHECK_ORIGIN` muss exakt dem Browser-Ursprung entsprechen, zum Beispiel `https://webcheck.example.de` oder `http://192.168.1.50:3000`, ohne abschließenden Schrägstrich. Fremde Hostnamen/Ursprünge werden weiterhin abgewiesen. Basic-Anmeldung ist für alle Kundendaten notwendig; der Health-Endpunkt zeigt nur Betriebszustand und Version. Es gibt keine Mehrbenutzerverwaltung.

HTTP ist für ein vertrauenswürdiges LAN bzw. VPN vorgesehen. Für Internetzugriff einen HTTPS-Reverse-Proxy davor setzen, `WEBCHECK_ORIGIN` auf die HTTPS-Adresse ändern, den Host-Header weiterreichen und den Direktzugriff auf Port 3000 per Netzwerk-/Proxmox-Firewall beschränken. Ohne TLS wird das Basic-Passwort unverschlüsselt übertragen. Es wird kein Update-Port ins Internet geöffnet.

### 3. Verwaltung

```bash
sudo /opt/visionwave-webcheck/manage.sh status
sudo /opt/visionwave-webcheck/manage.sh logs
sudo /opt/visionwave-webcheck/manage.sh backup
```

Berichte und Screenshots: Docker-Volume `visionwave-webcheck-data`.
Sicherungen: `/opt/visionwave-webcheck/backups/*.tar.gz`.
Keine `docker compose down -v` oder Volume-Löschbefehle ausführen, wenn Berichte erhalten bleiben sollen. Proxmox-VM-Backups zusätzlich aktivieren; Sicherungen enthalten Kundendaten. Alte Images erst löschen, wenn ein Rollback nicht mehr benötigt wird.

### 4. Vorhandene Windows-Berichte übernehmen

Auf Windows WebCheck beenden. Den bisherigen `data`-Ordner nach `/tmp/webcheck-data` auf die VM übertragen. Auf der VM:

```bash
sudo docker stop visionwave-webcheck-webcheck-1
sudo docker run --rm --user 0 --entrypoint sh \
  -v visionwave-webcheck-data:/app/data \
  -v /tmp/webcheck-data:/import:ro \
  mcr.microsoft.com/playwright:v1.58.2-noble \
  -c 'cp -a /import/. /app/data/ && chown -R 1000:1000 /app/data'
sudo docker start visionwave-webcheck-webcheck-1
```

Vorhandene Bericht-IDs werden dabei gegebenenfalls überschrieben; deshalb nur zur Erstübernahme in ein neues Volume verwenden. Alte Prüfungen können direkt mit der aktuellen PDF-Gestaltung exportiert werden.

## Updates aus ZIP

Neue Version entpacken und auf die VM kopieren:

```bash
sudo /opt/visionwave-webcheck/manage.sh update /tmp/neue-version/webcheck
```

Das neue Image wird zuerst vollständig gebaut. Ein aktiver Scan verhindert anschließend den Wechsel. Vor dem Wechsel wird der Dienst kurz gestoppt und das komplette Datenvolume gesichert. Der Compose-Start wartet auf den Healthcheck. Schlägt der Start fehl, wird das vorherige Image wieder aktiviert. Das Verfahren verwendet stets dasselbe Datenvolume und denselben Projektnamen. Bei Updates während eines laufenden Scans nach dessen Abschluss wiederholen.

Zurück zur vorherigen Version:

```bash
sudo /opt/visionwave-webcheck/manage.sh rollback
```

Rollback wechselt das Image, nicht die Daten. Bei späteren Versionen mit Datenmigration muss zusätzlich eine passende Datensicherung zurückgespielt werden. Aktuell werden JSON-Berichte unverändert gespeichert.

## Updates aus ChatGPT: vorbereitete GitHub-Schnittstelle

Mitgeliefert: `.github/workflows/deploy.yml`. GitHub dient als nachvollziehbare Update-Schnittstelle. Ein **privates Repository** verwenden, das direkt den Inhalt des `webcheck`-Ordners enthält (`package.json` und `.github` im Repository-Hauptverzeichnis).

Einmalige Einrichtung:

1. Privates GitHub-Repository anlegen und dieses Projekt hochladen.
2. In Repository → Settings → Actions → Runners → New self-hosted runner einen **Linux x64 Runner** anlegen. Die dort angezeigten aktuellen Installations-/Registrierungsbefehle auf der dedizierten WebCheck-VM ausführen. Zusätzlich zum Standardlabel das Label **webcheck** vergeben. Runner als Systemdienst einrichten.
3. Das Runnerkonto benötigt den folgenden sudo-Zugriff auf das fest installierte Verwaltungsskript. In `sudo visudo -f /etc/sudoers.d/webcheck-runner` den tatsächlichen Benutzernamen einsetzen, beispielsweise `webcheck-runner`:

   ```text
   webcheck-runner ALL=(root) NOPASSWD: /opt/visionwave-webcheck/manage.sh update *, /opt/visionwave-webcheck/manage.sh status
   ```

4. In GitHub ein Deployment-Environment **production** anlegen. Optional eine erforderliche Freigabe einrichten. Schreibrechte und Tags ausschließlich vertrauenswürdigen Administratoren geben. Der Runner installiert Code mit Docker-Rechten und gehört deshalb in diese eigene VM, niemals auf den Proxmox-Host.
5. Das private Repository mit der GitHub-Verbindung in ChatGPT/Codex freigeben. Hier sind bislang weder ein Zielrepository noch ein Serverrunner eingerichtet.

Ablauf: Änderungen werden im privaten Repository bereitgestellt. Ein neu gepushter Tag `release-0.9.1` startet den Workflow. Zuerst läuft die vollständige Testsuite auf einem GitHub-Runner. Nur bei Erfolg installiert der lokale Runner denselben Commit mit Sicherung und Startprüfung. Es gibt keine Deployments für Pull Requests. Tags nicht nachträglich verschieben; pro Release einen neuen Tag verwenden.

Der Workflow kann über einen GitHub-Client/API oder die GitHub-Oberfläche gestartet werden, indem ein neuer Release-Tag gepusht/angelegt wird. Ein aus ChatGPT gestartetes Update setzt eine passende GitHub-Verbindung mit Schreib-/Tag-Rechten voraus; die verfügbaren Verbindungsfunktionen können variieren. Das Paket allein stellt noch keine aktive Verbindung zwischen dieser Unterhaltung und deiner VM her.

Die einmalige Registrierung und Zugangsdaten erfolgen auf GitHub bzw. der VM. Proxmox-Rootpasswort oder Serverpasswörter müssen nicht in diese Unterhaltung eingefügt werden.

## Prüfstatus dieser Auslieferung

Serverzugriff, Authentifizierung, bisherige Website-Prüfungen und PDF-Export werden automatisiert geprüft. Shellskripte werden syntaktisch geprüft; der Verwaltungsablauf wird mit einem simulierten Docker-Dienst getestet, insbesondere fehlgeschlagene Starts und Sicherungen. Ein echter Docker-Build, eine Proxmox-Installation und ein GitHub-Deployment konnten in dieser Arbeitsumgebung ohne Docker/Serverzugriff nicht ausgeführt werden. Diese Schritte sind beim ersten Start auf deiner VM zu verifizieren.

Referenzen:
- https://pve.proxmox.com/pve-docs/pve-admin-guide.html
- https://docs.docker.com/engine/install/debian/
- https://docs.docker.com/compose/how-tos/production/
- https://docs.github.com/en/actions/hosting-your-own-runners/managing-self-hosted-runners/adding-self-hosted-runners
