import test from 'node:test';
import assert from 'node:assert/strict';
import {mkdtemp,mkdir,writeFile,readFile,rm} from 'node:fs/promises';
import {tmpdir} from 'node:os';
import path from 'node:path';
import {spawnSync} from 'node:child_process';
const script=await readFile(new URL('../deploy/manage.sh',import.meta.url),'utf8');
for(const scenario of ['success','build-fail','active','backup-fail','start-fail'])test('Deployment: '+scenario,async()=>{
 const dir=await mkdtemp(path.join(tmpdir(),'webcheck-deploy-'));const base=path.join(dir,'installed'),source=path.join(dir,'source'),bin=path.join(dir,'bin');
 try{
  await Promise.all([mkdir(base),mkdir(bin),mkdir(path.join(source,'src'),{recursive:true}),mkdir(path.join(source,'public'),{recursive:true}),mkdir(path.join(source,'assets'),{recursive:true})]);
  for(const name of ['Dockerfile','package-lock.json','src/server.js','public/index.html','assets/letterhead.png'])await writeFile(path.join(source,name),'fixture');
  await writeFile(path.join(source,'package.json'),JSON.stringify({version:'0.9.0'}));
  await writeFile(path.join(base,'config.env'),'fixture');await writeFile(path.join(base,'compose.yaml'),'fixture');await writeFile(path.join(base,'image.env'),'WEBCHECK_IMAGE=old-image\n');
  const manage=path.join(dir,'manage.sh');await writeFile(manage,script.replace('/opt/visionwave-webcheck',base));
  await writeFile(path.join(bin,'docker'),`#!/usr/bin/env bash
printf '%s\\n' "$*" >> "$LOG"
if [[ $1 == build && $SCENARIO == build-fail ]]; then exit 1; fi
if [[ $1 == run ]]; then
 [[ $SCENARIO != backup-fail ]] || exit 1
 echo 'backup-fixture';exit 0
fi
if [[ $* == *' exec '* ]]; then
 [[ $SCENARIO != active || \${!#} != idle ]] || exit 2
 echo '{"ok":true,"active":false,"version":"0.9.0"}';exit 0
fi
if [[ $* == *' up '* && $SCENARIO == start-fail ]] && ! grep -q 'old-image' image.env; then exit 1; fi
exit 0
`,{mode:0o755});
  const log=path.join(dir,'log');const result=spawnSync('bash',[manage,'update',source],{env:{...process.env,PATH:bin+':'+process.env.PATH,SCENARIO:scenario,LOG:log},encoding:'utf8'});
  const calls=await readFile(log,'utf8'),image=await readFile(path.join(base,'image.env'),'utf8');
  assert.equal(result.status,scenario==='success'?0:1,result.stderr);
  if(scenario==='success'){assert.match(image,/visionwave-webcheck:0.9.0/);assert.match(calls,/visionwave-webcheck-data:\/data:ro/);assert.match(await readFile(path.join(base,'previous-image.env'),'utf8'),/old-image/);}
  else assert.match(image,/old-image/);
  if(['build-fail','active'].includes(scenario))assert.doesNotMatch(calls,/ stop /);
  if(['backup-fail','start-fail'].includes(scenario))assert.match(calls,/ up -d --no-build/);
 }finally{await rm(dir,{recursive:true,force:true});}
});
