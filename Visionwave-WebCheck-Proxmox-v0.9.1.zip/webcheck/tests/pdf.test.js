import test from 'node:test';
import assert from 'node:assert/strict';
import {PDFDocument,PDFName} from 'pdf-lib';
import {exportPdf} from '../src/pdf-export.js';
const report={id:'test-report',url:'https://beispiel.de',createdAt:'2026-10-08T09:00:00Z',ruleVersion:'Test',scope:{wcag:'2.2 A/AA',maxPages:3},pages:[{url:'https://beispiel.de',status:'ok'}],errors:[],issues:[{area:'WCAG',status:'Mangel',title:'Formularfeld ohne Beschriftung',url:'https://beispiel.de/kontakt',detail:'Ein zugänglicher Name fehlt.',rule:'wcag412',evidence:[{selector:['#email'],fix:'Eine passende Beschriftung ergänzen.'}]}],review:{keyboard:'yes',notes:'Überprüfung: äöü ß €'},limitations:['Keine Konformitätsbestätigung.']};
test('Kunden-PDF: Briefpapier, mehrseitige lange Inhalte und Schriftzeichen',async()=>{
 const bytes=await exportPdf({...report,issues:Array.from({length:12},()=>report.issues[0])},{customer:'Musterkunde GmbH',title:'Prüfbericht – Beispiel',comment:'Test '+('SehrLangesWortOhneLeerzeichen'.repeat(100))});
 const pdf=await PDFDocument.load(bytes);assert.ok(pdf.getPageCount()>2);assert.equal(pdf.getAuthor(),'Visionwave Media');assert.equal(pdf.getTitle(),'Prüfbericht - Beispiel');
 const toc=pdf.getPages()[1].node.Annots();assert.equal(toc.size(),8);
 const targetRefs=new Set();
 for(let i=0;i<toc.size();i++){
  const annotation=pdf.context.lookup(toc.get(i));
  const action=pdf.context.lookup(annotation.get(PDFName.of('A')));
  assert.equal(action.get(PDFName.of('S')).toString(),'/GoTo');
  const destination=pdf.context.lookup(action.get(PDFName.of('D')));
  const ref=destination.get(0).toString();targetRefs.add(ref);
  assert.ok(pdf.getPages().slice(2).some(p=>p.ref.toString()===ref));
 }
 assert.equal(targetRefs.size,8);
 for(const page of pdf.getPages()){assert.ok(page.getWidth()>590);assert.ok(page.getHeight()>840);}
});
