import test from 'node:test';
import assert from 'node:assert/strict';
import http from 'node:http';
import {publicAddress,normalizeUrl,resolveTarget,fetchPinned} from '../src/network.js';
import {createServer} from '../src/server.js';
test('SSRF: lokale/reservierte IPv4, IPv6 und gemappte Adressen sperren',()=>{
 for(const address of ['127.0.0.1','10.0.0.1','172.16.1.1','192.168.0.1','169.254.169.254','0.0.0.0','224.0.0.1','::1','fc00::1','fe80::1','::ffff:127.0.0.1','192.0.2.1','2001:db8::1'])assert.equal(publicAddress(address),false,address);
 assert.equal(publicAddress('1.1.1.1'),true);assert.equal(publicAddress('2606:4700:4700::1111'),true);
});
test('URL: Dateischema, Credentials und fremde Ports sperren',()=>{
 for(const url of ['file:///etc/passwd','ftp://example.com','http://user:password@example.com','https://example.com:8080'])assert.throws(()=>normalizeUrl(url));
 assert.equal(normalizeUrl('https://example.com/#foo').href,'https://example.com/');
});
test('DNS-Prüfung sperrt localhost',async()=>{await assert.rejects(resolveTarget('http://localhost'));await assert.rejects(resolveTarget('http://127.0.0.1'));});
test('Lokale API: Oberfläche, CSRF, URL-Sperre und Fehlerstatus',async t=>{
 const server=createServer();await new Promise(r=>server.listen(0,'127.0.0.1',r));t.after(()=>server.close());const base=`http://127.0.0.1:${server.address().port}`;
 assert.equal((await fetch(base)).status,200);
 assert.equal((await fetch(base+'/api/health')).status,200);
 assert.equal((await fetch(base+'/api/scans',{method:'POST',headers:{Origin:'https://evil.example','Content-Type':'application/json'},body:'{}'})).status,403);
 const response=await fetch(base+'/api/scans',{method:'POST',headers:{'Content-Type':'application/json'},body:JSON.stringify({url:'http://127.0.0.1',authorized:true})});assert.equal(response.status,400);
 assert.equal((await fetch(base+'/api/reports/00000000-0000-0000-0000-000000000000')).status,404);
 const forbidden=await new Promise(resolve=>{http.get(base,{headers:{Host:'evil.example'}},res=>{res.resume();resolve(res.statusCode);});});assert.equal(forbidden,403);
});

test('DNS-Pinning: Hostname mit Node.js autoSelectFamily verbinden',async t=>{
 const server=http.createServer((req,res)=>res.end('DNS pinning works'));
 await new Promise(r=>server.listen(0,'127.0.0.1',r));t.after(()=>server.close());
 const url=`http://localhost:${server.address().port}`;
 const response=await fetchPinned(url,{},url);
 assert.equal(response.status,200);assert.equal(response.body.toString(),'DNS pinning works');
});
