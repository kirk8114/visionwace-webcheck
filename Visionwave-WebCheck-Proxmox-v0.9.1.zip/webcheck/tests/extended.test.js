import test from 'node:test';
import assert from 'node:assert/strict';
import {PDFDocument,PDFName} from 'pdf-lib';
import {inspectPdf,analyzeExtendedPage,analyzePerformance,runAuxiliaryChecks,compareReports} from '../src/extended-checks.js';
import {exportPdf} from '../src/pdf-export.js';
const url='https://beispiel.de/';
test('Zusatzchecks: SEO, Sicherheit, Formular und Medien getrennt erkennen',()=>{
 const probe={title:'',description:'',h1:0,robots:'noindex',canonical:'',ld:[false],insecure:['http://asset.de/a'],anchors:[{exists:false,url:url+'#fehlt'}],forms:[{missingLabels:1,emailWithoutType:1,noValidate:true,action:'http://beispiel.de/contact'}],media:[{type:'video',captions:false,controls:false},{type:'audio',controls:true}],externalPlayers:1,transcriptHint:false};
 const issues=analyzeExtendedPage({url,extendedProbe:probe,responseHeaders:{}});
 for(const area of ['SEO','Sicherheit','Links','Formulare','Medien'])assert.ok(issues.some(i=>i.area===area));
 assert.ok(issues.some(i=>i.title==='Formularziel ist unverschlüsselt'&&i.status==='Mangel'));
});
test('Performance: Wiederholungen, fehlende Werte und Grenzwerte',()=>{
 const result=analyzePerformance([{ok:true,lcpMs:2800,cls:.2,bytes:3000000,requests:5},{ok:true,lcpMs:3100,cls:.3,bytes:3500000,requests:7},{ok:false,lcpMs:100}],url);
 assert.equal(result.successfulRuns,2);assert.equal(result.issues.length,3);assert.equal(result.lcpMs,3100);
 assert.equal(analyzePerformance([{ok:false}],url).lcpMs,null);
});
test('Links: Begrenzung, externe Ziele, Parameter und Fehlercodes',async()=>{
 const called=[];const report={url,pages:[{extendedProbe:{links:[{url:url+'kaputt'},{url:'https://extern.de/'},{url:url+'?delete=1'},{url:url+'a'},{url:url+'b'}]}}]};
 const result=await runAuxiliaryChecks(report,async u=>{called.push(u);return {status:u.includes('kaputt')?404:200,headers:{},body:Buffer.from('<urlset></urlset>'),redirects:0};},{maxLinks:2});
 assert.equal(result.links.tested,2);assert.equal(result.links.truncated,true);assert.ok(result.issues.some(i=>i.area==='Links'&&i.status==='Mangel'));assert.ok(called.every(u=>u.startsWith(url)&&!u.includes('?')));
});
test('PDF: fehlende Struktur, Sprache und Titel bleiben Hinweise',async()=>{
 const p=await PDFDocument.create();p.addPage();const result=await inspectPdf(await p.save(),url+'angebot.pdf');assert.equal(result.pages,1);assert.equal(result.issues[0].status,'Verdacht');assert.equal(result.tagged,false);
});
test('Vergleich: nur gleicher Prüfumfang, Anzahl gleicher Befunde berücksichtigen',()=>{
 const issue={area:'Links',status:'Mangel',title:'Kaputt',url};const base={id:'alt',createdAt:'2026-10-01',ruleVersion:'v1',scope:{maxPages:1},pages:[{url}],errors:[],issues:[issue,issue]};
 assert.equal(compareReports({...base,issues:[issue]},base).disappeared,1);
 assert.equal(compareReports({...base,ruleVersion:'v2'},base).comparable,false);
 assert.equal(compareReports({...base,errors:[{}]},base).comparable,false);
});
test('PDF: vollständiger Bericht hat 16 gültige Kapitelziele und zweites Inhaltsverzeichnis',async()=>{
 const categories=Object.fromEntries(['Performance','SEO','Links','Sicherheit','Formulare','Medien'].map(k=>[k,[{url,summary:'Prüfumfang dokumentiert.'}]]));
 const report={url,createdAt:'2026-10-08',ruleVersion:'0.7.0',scope:{maxPages:1},pages:[{url,status:'ok',states:[]}],issues:[],errors:[],review:{},extended:{categories,performance:{successfulRuns:2,lcpMs:1000},links:{truncated:false}},comparison:{comparable:true,previousDate:'2026-10-01',added:0,disappeared:0,remaining:0,reason:'Vergleich'}};
 const p=await PDFDocument.load(await exportPdf(report));const refs=[];for(const page of p.getPages().slice(1,3)){const a=page.node.Annots();if(a)for(let i=0;i<a.size();i++){const ann=p.context.lookup(a.get(i));const action=p.context.lookup(ann.get(PDFName.of('A')));const d=p.context.lookup(action.get(PDFName.of('D')));refs.push(d.get(0).toString());}}
 assert.equal(refs.length,16);assert.equal(new Set(refs).size,16);assert.ok(refs.every(ref=>p.getPages().some(page=>page.ref.toString()===ref)));
});
