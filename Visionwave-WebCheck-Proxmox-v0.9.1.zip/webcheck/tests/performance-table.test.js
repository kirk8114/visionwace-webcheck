import test from 'node:test';
import assert from 'node:assert/strict';
import {performanceRows} from '../src/performance-table.js';
test('Soll/Ist: verfügbare Werte, Einheiten, Grenzen und neutrale individuelle Ziele',()=>{
 const rows=performanceRows({successfulRuns:2,lcpMs:2500,cls:0,bytes:3*1048576,domMs:1300,requests:42});
 assert.equal(rows.length,5);assert.equal(rows[0].color,'green');assert.equal(rows[0].actual,'2,50 s');assert.equal(rows[1].actual,'0,000');assert.equal(rows[2].color,'yellow');assert.equal(rows[3].target,'Individuell');assert.equal(rows[4].color,'gray');
 assert.equal(performanceRows({successfulRuns:2,lcpMs:4100,cls:.26})[0].color,'red');assert.equal(performanceRows({successfulRuns:2,lcpMs:null,cls:.11}).length,1);assert.deepEqual(performanceRows({successfulRuns:0,lcpMs:1000}),[]);
});
