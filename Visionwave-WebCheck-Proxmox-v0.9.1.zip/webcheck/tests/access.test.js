import test from 'node:test';
import assert from 'node:assert/strict';
import {accessConfig,checkAccess} from '../src/access.js';
const env={WEBCHECK_ORIGIN:'https://check.example.de',WEBCHECK_USER:'admin',WEBCHECK_PASSWORD:'0123456789abcdefghij'};
const config=accessConfig(env);
const req=(headers={},url='/api/reports')=>({headers:{host:'check.example.de',...headers},method:'GET',url});
const auth='Basic '+Buffer.from(env.WEBCHECK_USER+':'+env.WEBCHECK_PASSWORD).toString('base64');
test('Servermodus verweigert ungeschützte Konfiguration',()=>{
 assert.throws(()=>accessConfig({WEBCHECK_ORIGIN:env.WEBCHECK_ORIGIN}));
 for(const origin of ['https://check.example.de/path','https://check.example.de/','ftp://check.example.de'])assert.throws(()=>accessConfig({...env,WEBCHECK_ORIGIN:origin}));
});
test('Servermodus schützt Berichte auch bei lokalem Host und authentifiziert korrekt',()=>{
 assert.equal(checkAccess(req(),config),401);
 assert.equal(checkAccess(req({host:'localhost:3000'}),config),401);
 assert.equal(checkAccess(req({authorization:'Basic '+Buffer.from('admin:wrong').toString('base64')}),config),401);
 assert.equal(checkAccess(req({authorization:auth,origin:env.WEBCHECK_ORIGIN}),config),200);
 assert.equal(checkAccess(req({authorization:auth,origin:'https://evil.example'}),config),403);
 assert.equal(checkAccess(req({authorization:auth,host:'evil.example'}),config),403);
 assert.equal(checkAccess(req({authorization:auth,'sec-fetch-site':'cross-site'}),config),403);
 assert.equal(checkAccess(req({},'/api/health'),config),200);
});
test('Lokaler Modus bleibt ausschließlich lokal zugänglich',()=>{
 assert.equal(checkAccess(req({host:'localhost:3000'}),accessConfig({})),200);
 assert.equal(checkAccess(req(),accessConfig({})),403);
});
