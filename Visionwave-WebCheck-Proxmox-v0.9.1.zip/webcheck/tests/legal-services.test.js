import test from 'node:test';
import assert from 'node:assert/strict';
import {detectServices,servicesForRequests} from '../src/services.js';
import {analyzeLegalPages} from '../src/legal-checks.js';
import {customerGroups} from '../src/customer-text.js';
test('Dienste: Google Analytics, Ads und Tag Manager werden getrennt erkannt',()=>{
 assert.deepEqual(detectServices(['https://www.googletagmanager.com/gtag/js?id=AW-123']),['Google Ads']);
 assert.deepEqual(detectServices(['https://www.googletagmanager.com/gtag/js?id=G-123']),['Google Analytics']);
 assert.deepEqual(detectServices(['https://www.googletagmanager.com/gtm.js?id=GTM-123']),['Google Tag Manager']);
 assert.deepEqual(servicesForRequests([{url:'https://www.googletagmanager.com/gtag/js',detectedServices:['Google Ads']}]),['Google Ads']);
 assert.ok(detectServices(['https://googleadservices.com/pagead/conversion']).includes('Google Ads'));
});
test('Pflichtseiten: Erreichbarkeit, Inhaltssignale und Dienstabgleich bleiben Hinweise',()=>{
 const r={url:'https://example.com',pages:[{url:'https://example.com',imprintLinks:['https://example.com/impressum'],privacyLinks:['https://example.com/datenschutz'],states:[{services:['Google Ads']}]},{url:'https://example.com/datenschutz',reviewProbe:{documents:{privacy:true,privacySignals:{controller:true,purposes:true,basis:true,retention:true,rights:true},declaredServices:[]}}}]};
 const result=analyzeLegalPages(r);assert.ok(result.issues.some(i=>i.area==='Impressum'));assert.ok(result.issues.some(i=>i.title.includes('Dienste')));assert.ok(result.issues.every(i=>i.status==='Verdacht'));assert.equal(result.checks.services.comparisonPerformed,true);
});
test('Bericht: Schweregrad sortieren, gleiche Themen bündeln, alten GoBD-Befund auslassen',()=>{
 const inputs=[{area:'BFSG',status:'Manuell prüfen'},{area:'WCAG',title:'contrast',status:'Mangel',impact:'serious',url:'https://a.test/1'},{area:'WCAG',title:'contrast',status:'Mangel',impact:'serious',url:'https://a.test/2'},{area:'GoBD',status:'Manuell prüfen'}];
 const groups=customerGroups(inputs);assert.equal(groups.length,2);assert.equal(groups[0].priority.color,'red');assert.equal(groups[0].count,2);assert.equal(groups[0].urls.length,2);
});
