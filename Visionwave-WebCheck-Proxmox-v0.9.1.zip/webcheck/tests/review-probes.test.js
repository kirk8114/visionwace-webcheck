import test from 'node:test';
import assert from 'node:assert/strict';
import {buildAutoReview} from '../src/review-probes.js';
test('Alle 12 Prüffragen erhalten Ergebnisse; fehlende Nachweise werden nicht bestätigt',()=>{
 const r=buildAutoReview([]);assert.equal(Object.keys(r).length,12);assert.equal(r.micro.status,'unknown');assert.equal(r.keyboard.status,'unknown');
 const pages=[{url:'https://example.com',reviewProbe:{url:'https://example.com',signals:{contract:true,info:true,privacy:true,archive:true},keyboard:{testedTabs:30,focusedElements:20},reader:{treeAvailable:true,structuralFindings:0},mobile:{overflow:false,violations:0}},states:[]}];
 const p=buildAutoReview(pages);assert.equal(p.contract.status,'hint');assert.equal(p.micro.status,'unknown');assert.equal(p.mobile.status,'partial');assert.ok(p.reader.summary.includes('Kein echter Screenreader'));assert.equal(p.imprint.status,'unknown');
});
