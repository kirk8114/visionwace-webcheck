import test from 'node:test';
import assert from 'node:assert/strict';
import {trafficLight,customerFinding} from '../src/customer-text.js';
const complete={pages:[{status:'ok',states:[]}],coverage:{complete:true},errors:[],issues:[],review:{keyboard:'yes',reader:'yes',mobile:'yes',privacy:'yes',withdraw:'yes',contracts:'yes'}};
test('Ampel: unvollständige Prüfungen bleiben gelb; bestätigte Mängel rot',()=>{
 assert.equal(trafficLight({...complete,review:{}},'WCAG').color,'yellow');
 assert.equal(trafficLight({...complete,coverage:undefined},'WCAG').color,'yellow');
 assert.equal(trafficLight(complete,'WCAG').color,'green');
 assert.equal(trafficLight({...complete,issues:[{area:'WCAG',status:'Mangel'}]},'WCAG').color,'red');
 assert.equal(trafficLight({...complete,errors:[{}]},'DSGVO').color,'yellow');
 assert.equal(trafficLight(complete,'Impressum').color,'yellow');
 assert.equal(trafficLight(complete,'BFSG').color,'yellow');
 assert.equal(trafficLight({...complete,issues:[{area:'DSGVO',status:'Verdacht'}]},'DSGVO').color,'yellow');
});
test('Kundentext übernimmt keine technischen Codebelege',()=>{
 const r=customerFinding({area:'WCAG',title:'Label fehlt',detail:'<input id="x">',rule:'wcag412',evidence:[{selector:['#x'],html:'<input id="x">',fix:'aria-label setzen'}]});
 assert.ok(r.fix.includes('Bezeichnungen'));assert.ok(!JSON.stringify(r).includes('<input'));assert.ok(!JSON.stringify(r).includes('aria-label'));
});

test('Kundenbericht: gescheiterte Prüfversuche ausblenden, bestätigte negative Ergebnisse erhalten',async()=>{
 const {customerReportView,actionFor}=await import('../src/customer-report.js');
 const original={url:'https://beispiel.de',pages:[],issues:[{area:'Links',title:'Linkprüfung nicht erfolgreich'},{area:'Links',title:'Verlinkte Seite nicht erreichbar',status:'Mangel',detail:'HTTP 404'},{area:'Medien',title:'PDF konnte nicht geprüft werden'}],autoReview:{reader:{status:'unknown'},keyboard:{status:'partial',summary:'30 Tab-Schritte durchgeführt.'}},extended:{categories:{Links:[{summary:'Links geprüft'}],Performance:[{summary:'0 Durchläufe'}]},performance:{successfulRuns:0,lcpMs:null},links:{results:[{status:404},{error:'Zeitlimit'}]}}};
 const view=customerReportView(original);assert.equal(view.issues.length,1);assert.equal(view.issues[0].status,'Mangel');assert.equal(view.autoReview.reader,undefined);assert.ok(view.autoReview.keyboard);assert.equal(view.extended.categories.Performance,undefined);assert.equal(original.issues.length,3);
 assert.ok(actionFor(view.issues[0],'').includes('Zieladresse'));
});
