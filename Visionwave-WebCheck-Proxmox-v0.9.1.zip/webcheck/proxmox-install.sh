#!/usr/bin/env bash
# Visionwave WebCheck: lokaler Proxmox-Installer, unabhängig von Community Scripts.
set -Eeuo pipefail
[[ $EUID == 0 && -d /etc/pve ]] || { echo 'In der Proxmox-Host-Shell als root starten.'; exit 1; }
[[ $(uname -m) == x86_64 ]] || { echo 'Benötigt x86_64/amd64.'; exit 1; }
for command in pct pveam pvesm pvesh python3 tar ip; do command -v "$command" >/dev/null || { echo "Fehlendes Programm: $command"; exit 1; }; done
SOURCE=$(cd "$(dirname "$0")" && pwd)
for file in Dockerfile package.json deploy/install.sh deploy/install-docker-debian.sh src/server.js; do
 [[ -f "$SOURCE/$file" ]] || { echo "Paket unvollständig: $file"; exit 1; }
done
if [[ ${1:-} == --check ]]; then echo 'Proxmox-Werkzeuge und Installationspaket vorhanden. Keine Änderungen durchgeführt.'; pvesm status; exit 0; fi
[[ $# == 0 ]] || { echo 'Verwendung: bash proxmox-install.sh [--check]'; exit 1; }
echo 'Visionwave WebCheck – neuen Debian-13-LXC installieren'
echo 'Standard: unprivilegiert, 2 CPU, 4 GB RAM, 32 GB Disk, DHCP, Autostart.'
NEXTID=$(pvesh get /cluster/nextid --output-format json | python3 -c 'import json,sys;print(json.load(sys.stdin))')
read -r -p "Container-ID [$NEXTID]: " CTID; CTID=${CTID:-$NEXTID}
[[ $CTID =~ ^[1-9][0-9]{2,8}$ ]] || { echo 'Ungültige Container-ID.'; exit 1; }
if [[ -e /etc/pve/lxc/$CTID.conf || -e /etc/pve/qemu-server/$CTID.conf ]] || pct config "$CTID" >/dev/null 2>&1; then echo 'ID bereits vergeben. Bestehende Gäste werden nicht geändert.'; exit 1; fi
echo 'Verfügbare Speicher für Container:'
pvesm status --content rootdir
read -r -p 'Container-Speicher [local-lvm]: ' STORAGE; STORAGE=${STORAGE:-local-lvm}
echo 'Verfügbare Speicher für Templates:'
pvesm status --content vztmpl
read -r -p 'Template-Speicher [local]: ' TEMPLATE_STORAGE; TEMPLATE_STORAGE=${TEMPLATE_STORAGE:-local}
read -r -p 'Netzwerk-Bridge [vmbr0]: ' BRIDGE; BRIDGE=${BRIDGE:-vmbr0}
for value in "$STORAGE" "$TEMPLATE_STORAGE" "$BRIDGE"; do [[ $value =~ ^[a-zA-Z0-9_-]+$ ]] || { echo 'Ungültiger Speicher-/Bridge-Name.'; exit 1; }; done
ip link show "$BRIDGE" >/dev/null
pvesm status --content rootdir | awk -v target="$STORAGE" '$1==target && $3=="active" {found=1} END {exit !found}' || { echo 'Container-Speicher nicht aktiv oder unterstützt keine rootdir-Inhalte.'; exit 1; }
pvesm status --content vztmpl | awk -v target="$TEMPLATE_STORAGE" '$1==target && $3=="active" {found=1} END {exit !found}' || { echo 'Template-Speicher nicht aktiv oder unterstützt keine Templates.'; exit 1; }
echo "Es wird ausschließlich ein neuer Container $CTID auf $STORAGE angelegt."
read -r -p 'Installation starten? [j/N]: ' ANSWER
[[ $ANSWER == j || $ANSWER == J ]] || { echo 'Abgebrochen.'; exit 0; }
CREATED=0
BUNDLE=''
trap '[[ -z "$BUNDLE" ]] || rm -f "$BUNDLE"' EXIT
trap 'echo "Installation fehlgeschlagen. Bestehende Gäste wurden nicht geändert. Neuer CT: $CTID (angelegt: $CREATED). Details in der Ausgabe. Container bleibt zur Diagnose erhalten; keine automatische Löschung." >&2' ERR
pveam update
TEMPLATE=$(pveam available --section system | awk '$2 ~ /^debian-13-standard_.*_amd64.tar.zst$/ {print $2}' | sort -V | tail -n 1)
[[ -n $TEMPLATE ]] || { echo 'Kein Debian-13-amd64-Template verfügbar. Proxmox-Templatekatalog prüfen.'; exit 1; }
pveam download "$TEMPLATE_STORAGE" "$TEMPLATE"
pct create "$CTID" "$TEMPLATE_STORAGE:vztmpl/$TEMPLATE" \
 --hostname visionwave-webcheck --ostype debian --unprivileged 1 \
 --features nesting=1,keyctl=1 --cores 2 --memory 4096 --swap 512 \
 --rootfs "$STORAGE:32" --net0 "name=eth0,bridge=$BRIDGE,ip=dhcp,type=veth" \
 --onboot 1 --tags 'visionwave;webcheck' \
 --description 'Visionwave Media WebCheck – Docker in Debian LXC'
CREATED=1
pct start "$CTID"
ADDRESS=''
for attempt in {1..60}; do
 ADDRESS=$(pct exec "$CTID" -- ip -4 -o addr show dev eth0 scope global 2>/dev/null | awk '{split($4,a,"/");print a[1];exit}')
 [[ -z $ADDRESS ]] || break
 sleep 2
done
[[ $ADDRESS =~ ^[0-9]+\.[0-9]+\.[0-9]+\.[0-9]+$ ]] || { echo 'Keine IPv4-Adresse erhalten. DHCP/Bridge prüfen.'; exit 1; }
BUNDLE=$(mktemp /tmp/visionwave-webcheck.XXXXXX.tar.gz)
tar --exclude=node_modules --exclude=data --exclude='.git' --exclude='.superdesign' --exclude='*.env' --exclude='ui-*.png' -czf "$BUNDLE" -C "$SOURCE" .
pct push "$CTID" "$BUNDLE" /tmp/webcheck.tar.gz
pct exec "$CTID" -- mkdir -p /opt/webcheck-source
pct exec "$CTID" -- tar -xzf /tmp/webcheck.tar.gz -C /opt/webcheck-source
pct exec "$CTID" -- bash /opt/webcheck-source/deploy/install-docker-debian.sh
pct exec "$CTID" -- env "WEBCHECK_INSTALL_ADDRESS=$ADDRESS" WEBCHECK_INSTALL_USER=admin bash /opt/webcheck-source/deploy/install.sh
pct exec "$CTID" -- rm -f /tmp/webcheck.tar.gz
echo "Fertig: CT $CTID – http://$ADDRESS:3000"
echo 'DHCP-Reservierung für diese Adresse einrichten. Zugangsdaten stehen unmittelbar oberhalb.'
echo "Verwaltung: pct exec $CTID -- /opt/visionwave-webcheck/manage.sh status"
