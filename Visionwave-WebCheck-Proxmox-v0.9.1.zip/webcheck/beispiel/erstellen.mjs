import {writeFile} from 'node:fs/promises';
import {exportPdf} from '../src/pdf-export.js';
const base='https://beispiel.de';
const issues=[
 {area:'WCAG',status:'Mangel',impact:'critical',title:'Formularfeld ohne Beschriftung',rule:'label',url:base+'/kontakt'},
 {area:'WCAG',status:'Mangel',impact:'serious',title:'Textkontrast zu gering',rule:'color-contrast',url:base},
 {area:'WCAG',status:'Mangel',impact:'serious',title:'Textkontrast zu gering',rule:'color-contrast',url:base+'/kontakt'},
 {area:'Impressum',status:'Verdacht',title:'Impressum: Angaben möglicherweise unvollständig',url:base+'/impressum'},
 {area:'DSGVO',status:'Verdacht',title:'Tracking vor Einwilligung erkannt',url:base},
 {area:'DSGVO',status:'Verdacht',title:'Datenschutzerklärung: Erkannte Dienste nicht ausdrücklich benannt',url:base+'/datenschutz'},
 {area:'BFSG',status:'Manuell prüfen',title:'BFSG Anwendbarkeit fachlich prüfen',url:base}
];
const keys=['consumer','contract','other','micro','info','keyboard','reader','mobile','privacy','withdraw','contracts','imprint'];
const report={url:base,createdAt:'2026-10-08T09:00:00Z',ruleVersion:'2026-10-08 / MVP 0.9.0',pages:[base,base+'/impressum',base+'/datenschutz'].map(url=>({url,status:'ok',states:[{services:['Google Analytics','Google Ads','Google Fonts']}]})),issues,errors:[],scope:{maxPages:3,wcag:'2.2 A/AA'},review:{},coverage:{},legalChecks:{services:{comparisonPerformed:true}},autoReview:Object.fromEntries(keys.map(key=>[key,{summary:key==='micro'||key==='contracts'?'Dieser Punkt lässt sich anhand der öffentlichen Website nicht abschließend feststellen.':'Automatischer Prüfversuch durchgeführt. Die erkannten Hinweise müssen ergänzend bewertet werden.',next:'Ergebnisse mit den tatsächlichen Website-Funktionen und Betreiberangaben abgleichen.'}]))};
const categories={
 Performance:[{url:base,summary:'Zwei vollständige orientierende Labordurchläufe. Hauptinhalt nach etwa 3,2 Sekunden; beobachtete Layoutverschiebung 0,12. Keine echten Core-Web-Vitals-Nutzerdaten.'}],
 SEO:[{url:base,summary:'Titel vorhanden, Beschreibung fehlt, eine Hauptüberschrift. Sitemap an der Standardadresse erkannt.'}],
 Links:[{url:base,summary:'18 interne Links geprüft; ein Ziel nicht erreichbar. Externe Ziele nicht aufgerufen.'}],
 Sicherheit:[{url:base,summary:'HTTPS erkannt. Zertifikatslaufzeit und Sicherheitsheader untersucht; keine vollständige Sicherheitsbewertung.'}],
 Formulare:[{url:base+'/kontakt',summary:'Ein Formular mit drei Pflichtfeldern erkannt. Ungültige Testwerte in isolierten Feldkopien geprüft. Versand und tatsächliche Zustellung offen.'}],
 Medien:[{url:base+'/angebot.pdf',summary:'PDF mit vier Seiten: kein Strukturbaum erkannt. Dokumenttitel und Sprache vorhanden. Lesereihenfolge fachlich prüfen.'}],
 DSGVO:[{url:base,summary:'Wiederbesuch nach Ablehnung und Zustimmung versucht. Widerruf nicht eindeutig ausführbar. Granulare Auswahl fachlich prüfen.'}]
};
report.extended={categories,performance:{successfulRuns:2,runs:2,lcpMs:3200,cls:.12,bytes:2300000},links:{truncated:false}};
report.comparison={comparable:true,previousDate:'2026-10-01',disappeared:4,added:2,remaining:11,metrics:[{key:'lcpMs',before:4200,after:3200}],reason:'Fiktiver Vorher-/Nachher-Vergleich mit gleichem Prüfumfang. Nicht mehr erkannte Befunde sind kein unabhängiger Nachweis einer Behebung.'};
report.issues.push(...[
 ['Performance','Verdacht','Hauptinhalt erscheint langsam','Orientierende LCP-Labormessung: 3200 ms. Bilder und Ressourcen optimieren.',base],
 ['SEO','Verdacht','Suchergebnis-Beschreibung fehlt','Die Seite hat keine erkannte Beschreibung.',base],
 ['Links','Mangel','Verlinkte Seite nicht erreichbar','HTTP 404; die Adresse korrigieren.',base+'/angebot-alt'],
 ['Sicherheit','Verdacht','Inhaltssicherheitsrichtlinie prüfen','Der zugehörige Sicherheitsheader wurde nicht erkannt.',base],
 ['Formulare','Verdacht','E-Mail-Eingaben prüfen','E-Mail-Feld ohne passenden Eingabetyp erkannt.',base+'/kontakt'],
 ['Medien','Verdacht','PDF-Zugänglichkeit prüfen','Keine Strukturkennzeichnung im Dokument erkannt.',base+'/angebot.pdf']
].map(([area,status,title,detail,url])=>({area,status,title,detail,url,impact:'moderate'})));
await writeFile(new URL('./Visionwave-Kundenbericht-Beispiel.pdf',import.meta.url),await exportPdf(report,{customer:'Musterkunde GmbH (fiktiv)',project:'Website-Analyse - Beispiel',comment:'Fiktiver Bericht zur Vorschau. Alle Befunde und Zahlen sind Beispiele und betreffen keine tatsächlich geprüfte Kundenwebsite.'}));
