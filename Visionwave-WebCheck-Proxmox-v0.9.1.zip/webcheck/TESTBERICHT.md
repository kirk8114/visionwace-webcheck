# Teststand Visionwave Media WebCheck 0.2.0

Stand: 08.10.2026

## Bestanden

Acht automatisierte Tests mit Node.js 24 und einem separaten Chromium-143-Testbrowser:

1. Sperren für lokale, private, reservierte und IPv4-gemappte IPv6-Adressen.
2. URL-Sperren für andere Protokolle, Zugangsdaten und Nichtstandardports.
3. DNS-/Zielsperre für localhost und 127.0.0.1.
4. API-Aufruf, Oberfläche, Cross-Origin-Schutz, Host-Prüfung und Fehlerstatus.
5. Echte Browserprüfung einer kontrollierten Testseite: fehlende Formularbeschriftung durch axe erkannt, drei getrennte Cookie-Zustände, Datenschutz-Link erkannt, Zugriff auf Link-Local-Ziel gesperrt.
6. Bedienung der Oberfläche: Desktop und schmale Darstellung ohne horizontalen Überlauf, keine axe-Verstöße in Start- und Berichtsansicht, Fragebogen gespeichert, Filter und CSV-Download funktionieren; Notizen mit HTML werden als Text behandelt.

Oberfläche zusätzlich anhand Desktop- und Berichtsscreenshots visuell geprüft.
`npm ci` funktioniert. `npm audit --omit=dev`: keine gemeldeten Sicherheitslücken zum Testzeitpunkt.

## Nicht hier verifiziert

- Docker-Build und Docker-Start: Docker ist in der Ausführungsumgebung nicht installiert.
- Windows-Start: kein Zugriff auf das lokale Windows-Gerät.
- Reguläre Playwright-Chromium-Installation: Download in dieser Umgebung unbrauchbar; deshalb separater Testbrowser. Der ausgelieferte Code verwendet regulär Playwright Chromium 145 bzw. das passende Playwright-Docker-Image 1.58.2.
- Externe Live-Website: direkter DNS-Zugriff auf example.com endet hier mit EAI_AGAIN. Die Scan-Engine wurde mit einer kontrollierten Browser-Testseite geprüft; externe Website-Scans müssen auf dem lokalen Gerät oder Server bestätigt werden.
- Vollständige rechtliche Konformität und vollständige WCAG-Abdeckung: nicht Gegenstand automatisierter Softwaretests.

Das Paket ist eine getestete erste Implementierung. Installation und Zugriff auf echte Websites benötigen einen abschließenden Test in der Zielumgebung.

## Regressionstest Update 0.1.1

Der Hostnamen-Verbindungsfehler wurde mit Node.js 24 vor der Korrektur reproduziert: `ERR_INVALID_IP_ADDRESS: Invalid IP address: undefined`. Nach Korrektur des DNS-Lookup-Callbacks besteht derselbe Test mit HTTP 200. Ein zusätzlicher Regressionstest deckt Hostnamen und `autoSelectFamily` ab. Der eigentliche Scan von loggate.de muss wegen der Netzwerkbeschränkung dieser Umgebung auf dem Zielgerät erneut getestet werden.

## Update 0.2.0

- PDF-Exporter mit fest hinterlegtem Firmenpapier, Unicode-Schriften, Kundenfeldern und mehrseitigen langen Inhalten getestet.
- PDF-API und tatsächlicher Kunden-PDF-Download über die Oberfläche geprüft.
- Neue Oberfläche einschließlich Exportformular mit axe geprüft: keine automatisch erkannten Verstöße in den geprüften Zuständen.
- Fiktiven dreiseitigen Bericht mit Poppler gerendert und visuell geprüft; Briefpapier, reservierte Kopf-/Fußbereiche und Seitenzahlen auf allen Seiten.
- PDF ist kein PDF/UA-Dokument; kein Anspruch auf barrierefreie PDF-Konformität.

## Update 0.3.0

Zehn automatisierte Tests bestanden. Zusätzlich Ampel-Logik (offene Prüfungen bleiben gelb, bestätigte Mängel rot, kein pauschales grünes Konformitätsurteil) und Kundentext ohne übernommene Codebelege geprüft. Fünfseitiger fiktiver Beispielbericht gerendert und visuell geprüft: eigenständige Ampelübersicht auf Seite 1, verständliche Erläuterungen und Verbesserungsvorschläge auf Folgeseiten.

## Update 0.4.0

Elf Tests bestanden. Der Browser-Test prüft zusätzlich alle 15 Ergebnisfelder, 30 Tab-Schritte und tatsächlich erkannte Mängel bei 320 Pixel Breite. Ein weiterer Test sichert ab, dass nicht sichtbare Nachweise und Textsignale keine automatische Bestätigung erzeugen. Kunden-PDF mit zusätzlichen Prüfungsergebnissen als sechsseitiges fiktives Beispiel gerendert und geprüft.

## Update 0.5.0

14 Tests erfolgreich: bestehende Netzwerk-, API-, Browser-, Oberflächen- und PDF-Prüfungen sowie neue Tests zur getrennten Erkennung von Analytics/Ads/Tag Manager, Dienstmetadaten trotz bereinigter URLs, rechtlichen Dokumenten, Schweregradsortierung, Gruppierung und Ausblendung alter GoBD-Befunde. Testbrowser: Chromium 143, Node.js 24.

Der fiktive Kundenbericht wurde neu erzeugt (8 Seiten), gerendert und visuell auf Lesbarkeit, Seitenumbrüche, Statistik und Ampelüberschriften kontrolliert. Kein Live-Nachweis für die Rechtskonformität einer externen Website. Docker und Windows-Installation wurden hier nicht ausgeführt.

## Update 0.6.0

14 Tests erfolgreich, einschließlich acht interner Inhaltsverzeichnis-Links mit unterschiedlichen gültigen Kapitelseiten und langer Berichtsinhalte. Titelblatt, Statistik, Kapitelüberschriften, Fortsetzungsseiten und tatsächliche Inhaltsverzeichnis-Ziele am neu erzeugten PDF visuell bzw. strukturell geprüft. Keine Änderungen an der Scanlogik; Windows- und Docker-Start weiterhin auf dem Zielgerät zu testen.

## Update 0.7.0

20 Tests erfolgreich (Node.js 24, Chromium 143): echte Browser-/axe-Prüfungen, Cookie-Wiederbesuch und ausführbarer Widerruf auf Testseite, Formular-Validierungsprobe ohne POST-Versand, verlinkte 404-Seite, echte PDF-Ladung/Strukturprüfung, Performanceaggregation, zusätzliche Prüfbereiche, Linkbudgets/ausgelassene externe Ziele, vergleichbarer/unvergleichbarer Vorbericht sowie 16 gültige Kapitelziele über zwei Inhaltsverzeichnisse. Bestehende Netzwerk-, DNS-, API- und UI-Prüfungen weiterhin erfolgreich.

Der erweiterte fiktive Kundenbericht wurde gerendert und visuell auf Logo/Adresse nur auf dem Titelblatt, Übersicht/Statistik, Kategorien, Seitenumbrüche und Verbesserungshinweise geprüft. Performance ist eine orientierende Messung im abgesicherten Scanner. Windows/Docker und reale Kundenwebsites hier nicht neu getestet.

## Update 0.8.0

21 Tests erfolgreich. Zusätzlich geprüft: Kundenbericht-Filter entfernt gescheiterte Prüfversuche, erhält echte negative Ergebnisse (z. B. HTTP 404), verändert die Rohdaten nicht und wertet fehlende Performance nicht positiv. PDF-/Filter-/Inhaltsverzeichnis-Tests nach Layoutänderungen erneut erfolgreich. Neuer Beispielbericht gerendert und visuell auf Titelblatt, einzelne Kapitelüberschriften, Abstände und Statistik geprüft. Scanlogik unverändert.

## Update 0.8.1

Acht betroffene PDF-, Performance- und Zusatzcheck-Tests erfolgreich. Soll/Ist-Test prüft Grenzwerte, Einheiten, Nullwerte, fehlende Messwerte und neutrale individuelle Ziele. Beispiel-PDF gerendert und Tabelle visuell kontrolliert; Scanlogik unverändert.

## Update 0.8.2

Sieben betroffene PDF-/Zusatzcheck-Tests erfolgreich. Titelblatt und Inhaltsverzeichnis gerendert und visuell auf vergrößertes Logo, entfernte Firmenkontaktdaten und ausreichende Abstände geprüft.

## Update 0.8.3

Generische Ampel-Begründungstexte im Kunden-PDF entfernt. Beispielbericht neu erzeugt; markierte Formulierungen per Textextraktion ausgeschlossen. PDF-Tests und visuelle Kontrolle der Übersicht.

## Update 0.8.5

PDF-Test mit langen Inhalten erfolgreich; Titelblatt gerendert und vertikale Zentrierung visuell geprüft.

## Update 0.9.0: Proxmox-Serverpaket

Servermodus mit explizitem Ursprung und Basic-Anmeldung; lokale Betriebsart bleibt erhalten. Neues Deploymentpaket mit Debian-Docker-Installer, eigener Server-Compose-Datei, Verwaltungsskript, Datensicherung, Updateprüfung und Image-Rollback. GitHub-Workflow für private Release-Tags und dedizierten VM-Runner. Authentifizierung und simulierte Deploymentfehler werden automatisiert getestet. Echter Docker-Build und Proxmox-/GitHub-Installation hier mangels Docker und Serverzugriff nicht durchgeführt.

## 0.9.1: LXC-Installer

Host-Installer syntaktisch geprüft. Authentifizierungs- und simulierte Deploymenttests erfolgreich. Kein Zugriff auf einen echten Proxmox-Host: LXC-Erstellung und verschachtelter Dockerstart müssen bei Erstinstallation verifiziert werden.
