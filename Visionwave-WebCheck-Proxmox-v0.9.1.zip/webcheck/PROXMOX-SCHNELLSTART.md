# WebCheck mit einem Proxmox-Installationsskript

## Installation

1. ZIP auf deinem PC entpacken.
2. Den vollständigen Ordner `webcheck` mit WinSCP nach `/root/webcheck` auf den **Proxmox-Host** übertragen.
3. In Proxmox den Host auswählen und **Shell** öffnen:

```bash
bash /root/webcheck/proxmox-install.sh
```

Der Installer fragt Container-ID, Speicher und Bridge ab. Standardwerte: nächste freie ID, `local-lvm` für den Container, `local` für Templates, `vmbr0` für das Netzwerk. Nur bestätigen, wenn diese Speicher/Bridge auf deinem Host vorhanden sind.

Anschließend erstellt er einen neuen unprivilegierten Debian-13-LXC mit 2 Kernen, 4 GB RAM, 32 GB Festplatte und Autostart. Nesting und Keyctl werden für Docker aktiviert. Docker, Browser und WebCheck werden im LXC installiert. URL, Benutzer `admin` und zufälliges Passwort erscheinen am Ende. Bestehende VMs/Container werden nicht geändert. Bei Fehlern bleibt der neue Container zur Diagnose erhalten.

Nur Voraussetzungen prüfen, ohne einen Container anzulegen:

```bash
bash /root/webcheck/proxmox-install.sh --check
```

Voraussetzungen: x86_64-Proxmox, aktiver rootdir- und Template-Speicher, DHCP auf der gewählten Bridge, Internetzugang für Debian-Pakete, Docker und Microsoft-Containerimages. Der erste Image-Download benötigt Zeit und mehrere GB Platz. Den gesamten Ordner übertragen, nicht nur das Skript.

## Nach der Installation

Im Browser die angezeigte URL öffnen und anmelden. Im DHCP-Server/Router eine Reservierung für die Container-IP einrichten: Bei einem späteren IP-Wechsel muss `WEBCHECK_ORIGIN` in `/opt/visionwave-webcheck/config.env` im Container angepasst und die Anwendung neu erstellt werden. Zugangsdaten sicher speichern. Für externen Zugriff HTTPS bzw. VPN verwenden; HTTP-Anmeldung nur im vertrauenswürdigen LAN.

Verwaltung aus der Proxmox-Shell (`123` durch deine Container-ID ersetzen):

```bash
pct exec 123 -- /opt/visionwave-webcheck/manage.sh status
pct exec 123 -- /opt/visionwave-webcheck/manage.sh backup
pct exec 123 -- /opt/visionwave-webcheck/manage.sh rollback
```

Neue Version mit WinSCP **in den Container** übertragen, beispielsweise nach `/tmp/webcheck`; anschließend:

```bash
pct exec 123 -- /opt/visionwave-webcheck/manage.sh update /tmp/webcheck
```

Die GitHub-Updateanbindung ist weiterhin möglich; Anleitung unter `deploy/PROXMOX.md`. Dafür den Runner im WebCheck-Container einrichten, nicht auf dem Proxmox-Host.

## Einordnung und Prüfstatus

Dies ist ein eigener Installer im Stil der Community Scripts. Er ist nicht auf community-scripts.org veröffentlicht und hat deshalb noch keine öffentlich erreichbare curl-Installationsadresse. Ein öffentlicher Einzeiler kann nach Veröffentlichung der Quellen und des Pakets in einem erreichbaren Repository ergänzt werden.

Syntax und bestehende Anwendungstests werden geprüft. Eine echte Proxmox-/LXC-Installation konnte hier nicht ausgeführt werden. Docker-in-LXC kann je nach Proxmox-Kernel/AppArmor-Version zusätzliche Kompatibilitätsprobleme haben. Das Skript schaltet AppArmor nicht ab und stellt nicht automatisch auf einen privilegierten Container um. Falls der Docker-Start am Hostschutz scheitert, die bereits mitgelieferte Debian-VM-Installation nutzen; sie ist weiterhin die robustere Alternative.
