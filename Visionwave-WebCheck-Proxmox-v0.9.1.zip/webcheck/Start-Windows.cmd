@echo off
setlocal
cd /d "%~dp0"
where node >nul 2>nul
if errorlevel 1 (
 echo Bitte Node.js 22 oder 24 LTS von https://nodejs.org installieren.
 pause
 exit /b 1
)
echo Installiere Abhaengigkeiten ...
call npm ci --no-audit --no-fund
if errorlevel 1 goto fail
call npx playwright install chromium
if errorlevel 1 goto fail
start "" "http://localhost:3000"
call npm start
pause
exit /b
:fail
echo Installation fehlgeschlagen. Internetverbindung und Meldungen pruefen.
pause
exit /b 1
