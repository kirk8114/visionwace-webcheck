import {mentionedServices} from './services.js';
export function analyzeLegalPages(report){
 const pages=report.pages||[],issues=[];
 const links=key=>[...new Set(pages.flatMap(p=>p[key]||[]))];
 const imprint=pages.filter(p=>p.reviewProbe?.documents?.imprint),privacy=pages.filter(p=>p.reviewProbe?.documents?.privacy);
 const add=(area,title,detail,url)=>issues.push({area,status:'Verdacht',title,detail,url,evidence:[],rule:area==='Impressum'?'DDG § 5 (fachliche Einordnung erforderlich)':'DSGVO Art. 13 (fachliche Einordnung erforderlich)'});
 const imprintLinks=links('imprintLinks'),privacyLinks=links('privacyLinks');
 if(!imprintLinks.length&&!imprint.length)add('Impressum','Kein Impressum-Link erkannt','Im Prüfumfang wurde kein eindeutig benannter Impressum-Link erkannt. Erforderlichkeit, leichte Erkennbarkeit und Erreichbarkeit fachlich prüfen.',report.url);
 if(imprintLinks.length&&!imprint.length)add('Impressum','Impressum-Inhalt noch nicht geprüft','Ein Impressum-Link wurde gefunden, aber die Zielseite konnte im Scanumfang nicht als Impressum untersucht werden. Seitenlimit erhöhen oder die Zielseite separat prüfen.',imprintLinks[0]);
 if(privacyLinks.length&&!privacy.length)add('DSGVO','Datenschutzerklärung noch nicht inhaltlich geprüft','Ein Datenschutz-Link wurde erkannt, die Erklärung jedoch nicht als eigene Seite untersucht. Seitenlimit erhöhen oder die Erklärung separat prüfen.',privacyLinks[0]);
 for(const p of imprint){
  const fields=p.reviewProbe.documents.imprintSignals||{};
  const missing=Object.entries({operator:'Anbieterkennzeichnung',address:'Anschrift',email:'E-Mail-Kontakt'}).filter(([k])=>!fields[k]).map(([,v])=>v);
  if(missing.length)add('Impressum','Impressum: Angaben nicht eindeutig erkannt',`Die Textsuche konnte folgende Angaben nicht eindeutig erkennen: ${missing.join(', ')}. Dies beweist keinen Rechtsverstoß. Angaben und weitere situationsabhängige Pflichten fachlich prüfen.`,p.url);
 }
 for(const p of privacy){
  const fields=p.reviewProbe.documents.privacySignals||{};
  const missing=Object.entries({controller:'Verantwortlicher',purposes:'Verarbeitungszwecke',basis:'Rechtsgrundlagen',retention:'Speicherdauer',rights:'Betroffenenrechte'}).filter(([k])=>!fields[k]).map(([,v])=>v);
  if(missing.length)add('DSGVO','Datenschutzerklärung: Themen nicht eindeutig erkannt',`Die Textsuche konnte folgende Themen nicht eindeutig erkennen: ${missing.join(', ')}. Vollständigkeit und Eignung anhand der tatsächlichen Datenverarbeitung prüfen.`,p.url);
 }
 const detected=[...new Set(pages.flatMap(p=>(p.states||[]).flatMap(s=>s.services||[])))];
 const declared=[...new Set(privacy.flatMap(p=>p.reviewProbe.documents.declaredServices||[]))];
 if(privacy.length){const missing=detected.filter(name=>!declared.includes(name));if(missing.length)add('DSGVO','Dienste nicht eindeutig in Datenschutzerklärung erwähnt',`Im Netzwerk erkannte Dienste ohne passenden Texttreffer in den geprüften Datenschutzhinweisen: ${missing.join(', ')}. Beschreibung, Zweck und Rechtsgrundlage fachlich abgleichen.`,privacy[0].url);}
 return {issues,checks:{imprint:{links:imprintLinks,examinedPages:imprint.map(p=>p.url)},privacy:{links:privacyLinks,examinedPages:privacy.map(p=>p.url)},services:{detected,declared,comparisonPerformed:privacy.length>0}}};
}
