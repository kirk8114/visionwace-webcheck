import {chromium} from 'playwright';
import axe from 'axe-core';
import germanLocale from 'axe-core/locales/de.json' with {type:'json'};
import {resolveTarget,fetchPinned} from './network.js';
import {probePage,buildAutoReview} from './review-probes.js';
import {detectServices,servicesForRequests,trackingNames} from './services.js';
import {inspectExtendedPage,analyzeExtendedPage,analyzePerformance,runAuxiliaryChecks} from './extended-checks.js';
import {analyzeLegalPages} from './legal-checks.js';
import {mkdir} from 'node:fs/promises';
import path from 'node:path';

export const RULE_VERSION='2026-10-08 / MVP 0.9.1';
const actionNames = {reject:/^(alle ablehnen|ablehnen|nur notwendige|nur erforderliche|reject all|reject|deny all)$/i, accept:/^(alle akzeptieren|akzeptieren|alles akzeptieren|accept all|accept|zustimmen)$/i};
const services=servicesForRequests;
function issue(area,status,title,detail,url,evidence=[],rule='',impact=''){return {area,status,title,detail,url,evidence,rule,impact};}
export async function scanWebsite({url,maxPages=3,id,dataDir,onProgress=()=>{},testOrigin,launchOptions={}}) {
 const start=(await resolveTarget(url,testOrigin)).url;
 const browser=await chromium.launch({headless:true,args:['--disable-dev-shm-usage'],...launchOptions});
 const report={id,url:start.href,createdAt:new Date().toISOString(),ruleVersion:RULE_VERSION,scope:{maxPages,viewport:'1440 × 1000',wcag:'2.2 A/AA',states:['Ohne Auswahl','Ablehnung','Zustimmung']},pages:[],issues:[],errors:[],review:{},limitations:['Automatische Teilprüfung; keine Konformitätsbestätigung.','Nur Desktop, öffentliche Seiten und GET-Aufrufe. POST-Aufrufe, Downloads über 8 MB, WebSockets und Service Worker werden blockiert.','Cookie-Tests versuchen eindeutige Schaltflächen, Einstellungen, Wiederbesuch und Widerruf. Nicht erkannte Banner und granulare Einwilligungen bleiben fachlich offen.','Impressum und Datenschutzhinweise werden auf Verlinkung und Textsignale geprüft; keine vollständige juristische Bewertung.','Login, Checkout, echte Screenreader-Nutzung und tatsächliche Formularzustellung bleiben offen. PDF-Metadaten und Struktur werden stichprobenartig geprüft.']};
 const pending=[start.href],visited=new Set(); let totalRequests=0;
 const deadlineAt=Date.now()+360000;
 async function safeFetch(url){if(++totalRequests>1200||Date.now()>deadlineAt)throw new Error('Prüfbudget ausgeschöpft.');return fetchPinned(url,{},testOrigin,{timeoutMs:5000});}
 async function fetchFollowing(url){let current=url;for(let redirects=0;redirects<=5;redirects++){const r=await safeFetch(current);if(r.status>=300&&r.status<400&&r.headers.location){const next=new URL(r.headers.location,current);if(next.origin!==start.origin)throw new Error('Externes Weiterleitungsziel nicht im Linkprüfumfang.');current=next.href;continue;}return {...r,redirects};}throw new Error('Zu viele Weiterleitungen.');}
 async function protectedContext(){
  const context=await browser.newContext({viewport:{width:1440,height:1000},serviceWorkers:'block',acceptDownloads:false});
  const requests=[],blocked=[];const stage={phase:'before'};
  await context.route('**/*',async route=>{const req=route.request();if(req.method()!=='GET'){blocked.push({url:req.url().split('?')[0],reason:'HTTP-Methode gesperrt'});return route.abort();}try{if(++totalRequests>1200||Date.now()>deadlineAt)throw new Error('Prüfbudget ausgeschöpft.');const response=await fetchPinned(req.url(),await req.allHeaders(),testOrigin);requests.push({url:req.url().split('?')[0],status:response.status,phase:stage.phase,bytes:response.body.length,tls:response.tls,detectedServices:detectServices([req.url()])});const headers={};for(const [key,value] of Object.entries(response.headers))if(value!==undefined&&!['transfer-encoding','connection','content-length','content-encoding'].includes(key))headers[key]=Array.isArray(value)?value.join('\n'):String(value);if(response.headers['content-encoding'])headers['content-encoding']=response.headers['content-encoding'];await route.fulfill({status:response.status,headers,body:response.body});}catch(e){blocked.push({url:req.url().split('?')[0],reason:e.message});await route.abort().catch(()=>{});}});
  await context.routeWebSocket('**/*',socket=>socket.close());return {context,requests,blocked,stage};
 }
 const deadline=setTimeout(()=>browser.close().catch(()=>{}),360000);
 try {
 while(pending.length && visited.size<maxPages){
  const target=pending.shift(); if(visited.has(target))continue; visited.add(target); onProgress(`Seite ${visited.size}/${maxPages}: ${new URL(target).pathname}`);
  const entry={url:target,states:[],status:'ok'};
  for(const state of ['initial','reject','accept']){
   const {context,requests,blocked,stage}=await protectedContext();
   const page=await context.newPage();
   try {
    const response=await page.goto(target,{waitUntil:'domcontentloaded',timeout:30000});
    if(!response || response.status()>=400)throw new Error(`Seite nicht erfolgreich geladen: HTTP ${response?.status()??'unbekannt'}`);
    await page.waitForTimeout(1200);
    let action='Keine Auswahl durchgeführt';
    if(state!=='initial'){
      const matches=page.getByRole('button',{name:actionNames[state]}); let chosen=null;
      for(let i=0;i<await matches.count();i++)if(await matches.nth(i).isVisible()){chosen=matches.nth(i);break;}
      if(!chosen){const settings=page.getByRole('button',{name:/^(einstellungen|cookie-einstellungen|preferences|settings|auswahl anpassen)$/i});for(let i=0;i<await settings.count();i++)if(await settings.nth(i).isVisible()){await settings.nth(i).click({timeout:2000});break;}for(let i=0;i<await matches.count();i++)if(await matches.nth(i).isVisible()){chosen=matches.nth(i);break;}}
      if(chosen){stage.phase='after';await chosen.click({timeout:3000});await page.waitForTimeout(1200);action='Schaltfläche betätigt; Wirkung fachlich prüfen';}else action='Keine eindeutige sichtbare Schaltfläche gefunden – nicht geprüft';
    }
    if(state==='reject'||state==='accept'){
     stage.phase='revisit';await page.reload({waitUntil:'domcontentloaded',timeout:20000});await page.waitForTimeout(1800);
     entry.cookieChecks||=[];
     entry.cookieChecks.push({state,step:'revisit',services:services(requests.filter(r=>r.phase==='revisit')),action});
     if(state==='accept'){
      const reopen=page.getByRole('button',{name:/^(cookie-einstellungen|datenschutz-einstellungen|einwilligung widerrufen|cookie settings|privacy settings|einstellungen)$/i});let opened=false;
      for(let i=0;i<await reopen.count();i++)if(await reopen.nth(i).isVisible()){await reopen.nth(i).click({timeout:2000});opened=true;break;}
      const reject=page.getByRole('button',{name:actionNames.reject});let withdrawn=false;
      if(opened)for(let i=0;i<await reject.count();i++)if(await reject.nth(i).isVisible()){stage.phase='withdraw';await reject.nth(i).click({timeout:2000});withdrawn=true;break;}
      if(withdrawn){await page.reload({waitUntil:'domcontentloaded',timeout:20000});await page.waitForTimeout(1800);}
      entry.cookieChecks.push({state,step:'withdraw',performed:withdrawn,services:services(requests.filter(r=>r.phase==='withdraw'))});
     }
    }
    const cookies=(await context.cookies()).map(({name,domain,secure,httpOnly,sameSite,expires})=>({name,domain,secure,httpOnly,sameSite,expires}));
    const storage=await page.evaluate(()=>({local:Object.keys(localStorage),session:Object.keys(sessionStorage)})).catch(()=>({local:[],session:[]}));
    entry.states.push({state,action,cookies,storage,services:services(requests),postActionServices:state==='initial'?null:services(requests.filter(r=>r.phase==='after')),externalHosts:[...new Set(requests.map(r=>new URL(r.url).hostname).filter(h=>h!==new URL(target).hostname))],requests,blocked});
    if(state==='initial'){
     entry.responseHeaders=await response.allHeaders();entry.tls=requests.find(r=>r.url===target.split('?')[0])?.tls;
     entry.extendedProbe=await inspectExtendedPage(page);report.issues.push(...analyzeExtendedPage(entry));
     entry.title=await page.title();entry.finalUrl=page.url();
     const links=await page.locator('a[href]').evaluateAll(nodes=>nodes.map(n=>({href:n.href,text:n.textContent?.trim()||''})));
     for(const link of links){try{const u=new URL(link.href);u.hash='';if(u.origin===start.origin&&!/\.(pdf|zip|jpe?g|png|mp4)$/i.test(u.pathname)&&!u.search&&!/logout|delete|remove|abmelden/i.test(u.pathname)&&!visited.has(u.href)&&!pending.includes(u.href)&&pending.length<50)pending.push(u.href);}catch{}}
     entry.imprintLinks=links.filter(l=>/impressum|legal notice/i.test(l.text+' '+l.href)).map(l=>l.href);
     for(const legal of links.filter(l=>/datenschutz|privacy|impressum|legal notice/i.test(l.text+' '+l.href)).reverse()){try{const u=new URL(legal.href);u.hash='';if(u.origin===start.origin&&!visited.has(u.href)){const index=pending.indexOf(u.href);if(index>=0)pending.splice(index,1);pending.unshift(u.href);}}catch{}}
     entry.privacyLinks=links.filter(l=>/datenschutz|privacy/i.test(l.text+' '+l.href)).map(l=>l.href);
     if(!entry.privacyLinks.length)report.issues.push(issue('DSGVO','Verdacht','Kein Datenschutz-Link erkannt','Auf dieser Seite wurde kein eindeutig benannter Link erkannt. Vorhandensein und Erreichbarkeit manuell prüfen.',target));
     await page.evaluate(axe.source);
     await page.evaluate(locale=>window.axe.configure({locale}),germanLocale);
     const result=await page.evaluate(async()=>window.axe.run(document,{runOnly:{type:'tag',values:['wcag2a','wcag2aa','wcag21a','wcag21aa','wcag22aa']}}));
     entry.reviewProbe=await probePage(page,result);
     for(const finding of entry.reviewProbe.mobile.findings||[])report.issues.push(issue('WCAG','Mangel','Schmale Darstellung: '+finding.help,finding.description+' (320 Pixel Breite)',target,finding.nodes,finding.tags.join(', '),finding.impact));
     if(entry.reviewProbe.mobile.overflow)report.issues.push(issue('WCAG','Manuell prüfen','Horizontaler Überlauf in schmaler Darstellung','Bei 320 Pixel Breite ist seitliches Scrollen möglich. Prüfen, ob wesentliche Inhalte ohne seitliches Scrollen nutzbar sind oder eine zulässige Ausnahme vorliegt.',target));
     entry.accessibility={passedRules:result.passes.length,incompleteRules:result.incomplete.length,violations:result.violations.length};
     for(const violation of result.violations)report.issues.push(issue('WCAG','Mangel',violation.help,violation.description,target,violation.nodes.slice(0,20).map(n=>({selector:n.target,html:n.html,fix:n.failureSummary})),violation.tags.join(', '),violation.impact));
     for(const incomplete of result.incomplete)report.issues.push(issue('WCAG','Manuell prüfen',incomplete.help,'axe-core konnte diese Regel nicht abschließend bewerten.',target,incomplete.nodes.slice(0,10).map(n=>({selector:n.target})),incomplete.tags.join(', ')));
     await mkdir(path.join(dataDir,id),{recursive:true});
     await page.screenshot({path:path.join(dataDir,id,`page-${visited.size}.png`),fullPage:false});entry.screenshot=`/api/reports/${id}/page-${visited.size}.png`;
    }
   }catch(e){entry.status='partial'; report.errors.push({url:target,state,message:e.message,blocked});}
   finally{await context.close().catch(()=>{});}
  }
  const before=entry.states.find(s=>s.state==='initial');
  if(before){
   const tracking=before.services.filter(s=>trackingNames.includes(s));
   if(tracking.length)report.issues.push(issue('DSGVO','Verdacht','Bekannte Tracking-Dienste vor einer Auswahl angefragt',`Erkannte Dienste: ${tracking.join(', ')}. Zweck, Einwilligung und Rechtsgrundlage prüfen; eine Anfrage allein beweist keinen Rechtsverstoß.`,target));
   if(before.cookies.length||before.storage.local.length)report.issues.push(issue('DSGVO','Manuell prüfen','Speicherung ohne vorherige Auswahl festgestellt','Cookies und Local Storage auf Zweck und Erforderlichkeit nach § 25 TDDDG prüfen. Die Speicherung ist nicht automatisch unzulässig.',target,before.cookies.map(c=>({name:c.name,domain:c.domain}))));
  }
  for(const check of entry.cookieChecks||[]){const activeTracking=check.services.filter(s=>trackingNames.includes(s));if((check.state==='reject'||check.step==='withdraw'&&check.performed)&&activeTracking.length)report.issues.push(issue('DSGVO','Verdacht','Tracking nach Ablehnung oder Widerrufsversuch erkannt',`Schritt ${check.step}: ${activeTracking.join(', ')}. Tatsächliche Einwilligung und Dienste prüfen.`,target));}
  report.pages.push(entry);
 }
 onProgress('Zusatzprüfungen: Performance, Links und Dokumente');
 const samples=[];
 for(let run=0;run<2&&Date.now()<deadlineAt-8000;run++){
  const {context,requests,blocked}=await protectedContext();
  try{await context.addInitScript(()=>{window.__vitals={lcpMs:null,cls:0};try{new PerformanceObserver(list=>{for(const e of list.getEntries())window.__vitals.lcpMs=e.startTime;}).observe({type:'largest-contentful-paint',buffered:true});new PerformanceObserver(list=>{for(const e of list.getEntries())if(!e.hadRecentInput)window.__vitals.cls+=e.value;}).observe({type:'layout-shift',buffered:true});}catch{}});const p=await context.newPage();await p.goto(start.href,{waitUntil:'load',timeout:20000});await p.waitForTimeout(2000);const measured=await p.evaluate(()=>({...window.__vitals,domMs:performance.getEntriesByType('navigation')[0]?.domContentLoadedEventEnd}));samples.push({...measured,ok:blocked.length===0,bytes:requests.reduce((n,r)=>n+r.bytes,0),requests:requests.length});}catch(e){samples.push({ok:false,error:e.message});}finally{await context.close().catch(()=>{});}
 }
 const performance=analyzePerformance(samples,start.href);report.issues.push(...performance.issues);
 const auxiliary=await runAuxiliaryChecks(report,fetchFollowing,{deadline:deadlineAt});report.issues.push(...auxiliary.issues);
 const categoryResults={DSGVO:report.pages.map(p=>({url:p.url,summary:(p.cookieChecks||[]).map(c=>`${c.step==='revisit'?'Wiederbesuch nach '+(c.state==='reject'?'Ablehnung':'Zustimmung'):'Widerruf'}: ${c.performed===false?'keine eindeutige Bedienmöglichkeit erkannt':c.action||'Schaltfläche betätigt'}; bekannte Dienste ${c.services.join(', ')||'keine erkannt'}`).join('. ')+'. Granulare Kategorien und rechtliche Wirkung bleiben fachlich zu prüfen.'})),Performance:[{url:start.href,summary:`${performance.successfulRuns}/${performance.runs} vollständige Labordurchläufe. LCP ${performance.lcpMs==null?'nicht messbar':Math.round(performance.lcpMs)+' ms'}, Layoutverschiebung ${performance.cls==null?'nicht messbar':performance.cls.toFixed(3)}, Datenmenge ${performance.bytes==null?'offen':(performance.bytes/1048576).toFixed(2)+' MB'}. Abgesicherter Scanner mit Anfragevermittlung; keine realen Core-Web-Vitals-Nutzerdaten und kein INP-Nachweis.`}],Links:[{url:start.href,summary:`${auxiliary.links.tested} von ${auxiliary.links.available} geeigneten internen Links geprüft. ${auxiliary.links.truncated?'Auswahl oder Zeitbudget begrenzt.':'Alle erkannten geeigneten internen Links in diesem Umfang geprüft.'} Externe Links und Links mit Parametern nicht aufgerufen.`}],Medien:auxiliary.pdfs.map(p=>({url:p.url,summary:p.summary})),SEO:[{url:start.href,summary:`Standarddateien: robots.txt ${auxiliary.discovery['robots.txt']?.valid?'erkannt':'nicht bestätigt'}, sitemap.xml ${auxiliary.discovery['sitemap.xml']?.valid?'erkannt':'nicht bestätigt'}. Keine Rankingbewertung.`}],Sicherheit:[],Formulare:[]};
 for(const p of report.pages){const x=p.extendedProbe;if(!x)continue;categoryResults.SEO.push({url:p.url,summary:`Titel ${x.title?'vorhanden':'fehlt'}, Beschreibung ${x.description?'vorhanden':'fehlt'}, ${x.h1} Hauptüberschriften, Canonical ${x.canonical?'vorhanden':'nicht erkannt'}, ${x.ld.length} strukturierte Datensätze.`});categoryResults.Sicherheit.push({url:p.url,summary:`${new URL(p.url).protocol==='https:'?'HTTPS':'HTTP'}; Zertifikat ${p.tls?.validTo?'gültig bis '+p.tls.validTo:'nicht separat bestätigt'}. Sicherheitsheader und Ressourcen überprüft. Kein Penetrationstest.`});categoryResults.Formulare.push({url:p.url,summary:`${x.forms.length} Formulare erkannt; Pflichtfelder, Beschriftungen, Eingabetypen und Zieladressen geprüft. ${x.forms.reduce((n,f)=>n+f.required,0)} Pflichtfelder; ${x.forms.flatMap(f=>f.validationProbes||[]).filter(v=>v.invalidDetected).length} ungültige Testwerte durch Browser-Regeln erkannt (isolierte Feldkopien). Individuelle Fehlermeldungen bleiben offen. Kein Versand und kein Nachweis serverseitiger Verarbeitung oder Zustellung.`});categoryResults.Medien.push({url:p.url,summary:`${x.media.length} Video-/Audioelemente und ${x.externalPlayers} externe Player erkannt; ${x.transcriptHint?'Transkripthinweis erkannt.':'Kein eindeutiger Transkripthinweis erkannt.'} Externe Player und Untertitelqualität fachlich prüfen.`});}
 report.extended={categories:categoryResults,performance:{...performance,issues:undefined,samples},links:auxiliary.links,pdfs:auxiliary.pdfs.map(p=>({...p,issues:undefined})),discovery:auxiliary.discovery};
 report.limitations.push('Zusatzchecks: bis zu 40 interne Links und fünf PDFs unter 8 MB; zwei orientierende Performance-Labordurchläufe der Startseite. Keine externen Linkziele, kein INP-/CrUX-Nachweis, kein Formularversand, keine vollständige PDF- oder Multimedia-Konformitätsprüfung.');
 report.coverage={scannedPages:report.pages.length,successfulPages:report.pages.filter(p=>p.status==='ok').length,remainingKnownPages:pending.filter(p=>!visited.has(p)).length,complete:report.errors.length===0};
 if(!report.pages.length||report.pages.every(p=>!p.states.length)){const first=report.errors[0];const network=first?.blocked?.[0];throw new Error('Keine Seite konnte geprüft werden. '+(network ? `Netzwerkfehler bei ${network.url}: ${network.reason}` : first?.message || 'Unbekannter Ladefehler.'));}
 report.issues.push(issue('BFSG','Manuell prüfen','Anwendungsbereich und Dienstleistungsinformationen prüfen','BFSG-Fragebogen ausfüllen. Automatische WCAG-Ergebnisse ersetzen keine vollständige BFSG-Prüfung.',start.href));
 const legal=analyzeLegalPages(report);report.legalChecks=legal.checks;report.issues.push(...legal.issues);
 report.autoReview=buildAutoReview(report.pages);
 report.limitations.push('Zusätzliche Prüfversuche: Textsignale, 30 Tab-Schritte je Seite, zugänglicher Browser-Inhaltsbaum und schmale Darstellung mit 320 Pixeln. Kein vollständiger Screenreader-, Zoom- oder Prozessnachweis.');
 return report;
 } finally{clearTimeout(deadline);await browser.close().catch(()=>{});}
}
