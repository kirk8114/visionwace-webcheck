import http from 'node:http';
import {accessConfig,checkAccess} from './access.js';
import {readFile,writeFile,mkdir,readdir} from 'node:fs/promises';
import path from 'node:path';
import {fileURLToPath} from 'node:url';
import {randomUUID} from 'node:crypto';
import {scanWebsite} from './scanner.js';
import {compareReports} from './extended-checks.js';
import {resolveTarget} from './network.js';
import {exportPdf} from './pdf-export.js';
const root=path.resolve(path.dirname(fileURLToPath(import.meta.url)),'..');
export const dataDir=path.resolve(process.env.DATA_DIR||path.join(root,'data'));
const jobs=new Map();let active=false;
const idPattern=/^[a-f0-9-]{36}$/;
async function jsonBody(req){let body='';for await(const chunk of req){body+=chunk;if(body.length>100000)throw new Error('Anfrage zu groß.');}return JSON.parse(body||'{}');}
const send=(res,status,obj)=>{res.writeHead(status,{'Content-Type':'application/json; charset=utf-8'});res.end(JSON.stringify(obj));};
export function createServer(config=accessConfig()){return http.createServer(async(req,res)=>{
 res.setHeader('X-Content-Type-Options','nosniff');res.setHeader('Cache-Control','no-store');res.setHeader('Referrer-Policy','no-referrer');
 res.setHeader('Content-Security-Policy',"default-src 'self'; script-src 'self'; style-src 'self'; img-src 'self'; object-src 'none'; frame-ancestors 'none'; base-uri 'none'; form-action 'self'");
 try{
  const access=checkAccess(req,config);
  if(access!==200){if(access===401)res.setHeader('WWW-Authenticate','Basic realm="Visionwave WebCheck", charset="UTF-8"');return send(res,access,{error:access===401?'Anmeldung erforderlich.':'Zugriff gesperrt.'});}
  const pathname=new URL(req.url,'http://localhost').pathname;
  if(pathname==='/api/health')return send(res,200,{ok:true,version:'0.9.1',active});
  if(pathname==='/api/scans'&&req.method==='POST'){
   if(active)return send(res,409,{error:'Es läuft bereits eine Prüfung.'});
   const input=await jsonBody(req);const maxPages=Number(input.maxPages||3);
   if(!Number.isInteger(maxPages)||maxPages<1||maxPages>10)return send(res,400,{error:'Seitenzahl muss zwischen 1 und 10 liegen.'});
   if(input.authorized!==true)return send(res,400,{error:'Bitte die Berechtigung zur Prüfung bestätigen.'});
   await resolveTarget(input.url);const id=randomUUID();active=true;
   jobs.set(id,{id,status:'running',progress:'Browser wird gestartet'});
   scanWebsite({url:input.url,maxPages,id,dataDir,onProgress:progress=>jobs.set(id,{id,status:'running',progress})})
    .then(async report=>{await mkdir(dataDir,{recursive:true});let previous;for(const file of await readdir(dataDir)){if(!file.endsWith('.json'))continue;try{const p=JSON.parse(await readFile(path.join(dataDir,file),'utf8'));if(p.url===report.url&&(!previous||p.createdAt>previous.createdAt))previous=p;}catch{}}report.comparison=compareReports(report,previous);await writeFile(path.join(dataDir,id+'.json'),JSON.stringify(report,null,2));jobs.set(id,{id,status:'done',progress:'Prüfung abgeschlossen'});})
    .catch(e=>{console.error(`[Prüfung ${id}] ${e.message}`);jobs.set(id,{id,status:'error',error:e.message});}).finally(()=>{active=false;if(jobs.size>100)jobs.delete(jobs.keys().next().value);});
   return send(res,202,{id});
  }
  if(pathname.startsWith('/api/scans/')&&req.method==='GET')return send(res,200,jobs.get(pathname.split('/').pop())||{status:'error',error:'Prüfung nicht gefunden; möglicherweise Server neu gestartet.'});
  if(pathname==='/api/reports'&&req.method==='GET'){
   await mkdir(dataDir,{recursive:true});const list=[];
   for(const file of await readdir(dataDir)){if(!file.endsWith('.json'))continue;try{const r=JSON.parse(await readFile(path.join(dataDir,file),'utf8'));list.push({id:r.id,url:r.url,createdAt:r.createdAt,issues:r.issues.filter(i=>i.area!=='GoBD').length,errors:r.errors.length});}catch{}}
   return send(res,200,list.sort((a,b)=>b.createdAt.localeCompare(a.createdAt)));
  }
  const match=pathname.match(/^\/api\/reports\/([a-f0-9-]{36})(?:\/(page-\d+\.png|review|pdf))?$/);
  if(match&&idPattern.test(match[1])){
   const id=match[1];const file=path.join(dataDir,id+'.json');
   if(match[2]?.endsWith('.png')){res.setHeader('Content-Type','image/png');return res.end(await readFile(path.join(dataDir,id,match[2])));}
   const report=JSON.parse(await readFile(file,'utf8'));
   report.issues=report.issues.filter(i=>i.area!=='GoBD');
   for(const key of ['relevant','archive','documentation','export']){if(report.autoReview)delete report.autoReview[key];if(report.review)delete report.review[key];}
   report.limitations=(report.limitations||[]).filter(l=>!/GoBD|Buchhaltung/i.test(l));
   if(match[2]==='pdf'&&req.method==='POST'){
    const options=await jsonBody(req);
    for(const key of ['customer','project','title','comment'])if(options[key]!=null&&(typeof options[key]!=='string'||options[key].length>10000))return send(res,400,{error:'Ungültige Berichtsfelder.'});
    const bytes=await exportPdf(report,options);res.setHeader('Content-Type','application/pdf');res.setHeader('Content-Disposition',`attachment; filename="Visionwave-WebCheck-${id}.pdf"`);return res.end(Buffer.from(bytes));
   }
   if(match[2]==='review'&&req.method==='PUT'){
    const review=await jsonBody(req);report.review=review;report.reviewUpdatedAt=new Date().toISOString();
    await writeFile(file,JSON.stringify(report,null,2));return send(res,200,{ok:true});
   }
   if(req.method==='GET'&&!match[2])return send(res,200,report);
  }
  const publicFiles={'/':'index.html','/app.js':'app.js','/style.css':'style.css','/brand/logo.png':'brand/logo.png'};
  if(req.method==='GET'&&publicFiles[pathname]){const filename=publicFiles[pathname];res.setHeader('Content-Type',filename.endsWith('.png')?'image/png':filename.endsWith('.js')?'text/javascript':filename.endsWith('.css')?'text/css':'text/html; charset=utf-8');return res.end(await readFile(path.join(root,'public',filename)));}
  send(res,404,{error:'Nicht gefunden.'});
 }catch(e){send(res,e.code==='ENOENT'?404:400,{error:e.code==='ENOENT'?'Bericht nicht gefunden.':e.message});}
 });}
if(process.argv[1]===fileURLToPath(import.meta.url)){
 const host=process.env.HOST||'127.0.0.1';const port=Number(process.env.PORT||3000);
 createServer().listen(port,host,()=>console.log(`Visionwave Media WebCheck 0.9.1: http://localhost:${port}\nZum Beenden Strg+C drücken.`));
}
