// Presentation filtering never changes the saved technical scan or turns an unknown result into a pass.
const failedIssue=/^(PDF konnte nicht geprüft werden|Linkprüfung nicht erfolgreich|Widerruf nicht automatisch geprüft|Automatischer Prüfversuch nicht verfügbar)/i;
export function customerReportView(report){
 const issues=(report.issues||[]).filter(i=>i.area!=='GoBD'&&!failedIssue.test(i.title||''));
 const categories={};
 for(const [area,rows] of Object.entries(report.extended?.categories||{})){
  if(area==='Performance'&&(!report.extended.performance?.successfulRuns||report.extended.performance.lcpMs==null))continue;
  if(area==='Links'&&report.extended.links?.results?.length&&!report.extended.links.results.some(r=>Number.isFinite(r.status)))continue;
  let valid=rows.filter(r=>r.success!==false&&!/^(PDF-Inhalt nicht automatisch prüfbar|Prüfung fehlgeschlagen|Nicht ausgeführt)/i.test(r.summary||''));
  if(area==='Links'&&report.extended.links?.results){const checked=report.extended.links.results.filter(r=>Number.isFinite(r.status));valid=checked.length?[{url:report.url,summary:`${checked.length} interne Linkziele auf Statuscodes und Weiterleitungen geprüft. Externe Ziele und Links mit Parametern gehören nicht zu dieser Stichprobe.`}]:[];}
  if(area==='DSGVO'){const measured=(report.pages||[]).flatMap(p=>(p.cookieChecks||[]).filter(c=>c.performed!==false&&!/nicht geprüft|Keine eindeutige/i.test(c.action||'')).map(c=>({url:p.url,summary:`${c.step==='revisit'?'Wiederbesuch nach '+(c.state==='reject'?'Ablehnung':'Zustimmung'):'Widerrufsversuch'}: bekannte Dienste ${c.services?.join(', ')||'keine erkannt'}. Rechtliche Wirkung fachlich bewerten.`})));valid=measured;}
  valid=valid.map(r=>({...r,summary:(r.summary||'').replace(/; Zertifikat nicht separat bestätigt\./g,'.')}));
  if(valid.length)categories[area]=valid;
 }
 const autoReview=Object.fromEntries(Object.entries(report.autoReview||{}).filter(([,r])=>r&&r.status!=='unknown'&&r.success!==false&&r.status!=='error'&&r.status!=='failed'&&!/konnte.*nicht|nicht verfügbar|nicht durchgeführt/i.test(r.summary||'')));
 const eligible=new Set(['Impressum','DSGVO','WCAG','BFSG',...Object.keys(categories)]);
 if(report.extended&&!categories.Performance)eligible.delete('Performance');
 if(report.extended&&!categories.Links)eligible.delete('Links');
 const filtered=issues.filter(i=>eligible.has(i.area));
 return {...report,issues:filtered,autoReview,extended:report.extended?{...report.extended,categories}:undefined,comparison:report.comparison?.comparable&&filtered.length===(report.issues||[]).filter(i=>i.area!=='GoBD').length?report.comparison:undefined};
}
export function actionFor(issue,fallback){
 const t=(issue.title+' '+issue.detail).toLowerCase();
 if(issue.area==='Links')return /sprung/.test(t)?'Die Zielmarke auf der betroffenen Seite ergänzen oder den Sprungverweis korrigieren. Anschließend den Link im Browser erneut aufrufen.':'Die betroffene Zieladresse prüfen und den Link auf eine erreichbare, möglichst direkte Adresse ändern. Danach Link und Weiterleitung erneut testen.';
 if(issue.area==='SEO'){
  if(/beschreibung/.test(t))return 'Für jede betroffene Seite eine individuelle, verständliche Suchergebnis-Beschreibung hinterlegen, die Angebot und Nutzen erklärt. Anschließend prüfen, ob sie im Seitenquelltext ausgegeben wird.';
  if(/titel/.test(t))return 'Einen eindeutigen Seitentitel mit dem Seiteninhalt und Unternehmensnamen hinterlegen. Den ausgegebenen Titel nach der Änderung erneut kontrollieren.';
  if(/index/.test(t))return 'Mit dem Betreiber klären, ob die Seite bei Google erscheinen soll. Falls ja, die unbeabsichtigte Indexierungssperre entfernen und die Indexierung anschließend überprüfen.';
  if(/sitemap/.test(t))return 'Die vorhandene Sitemap-Adresse ermitteln, erreichbare öffentliche Seiten aufnehmen und die Sitemap über robots.txt oder die Search Console bekannt machen.';
  if(/strukturierte/.test(t))return 'Die fehlerhaften strukturierten Daten korrigieren und anschließend mit einem geeigneten Validator auf Lesbarkeit und zum Angebot passende Angaben prüfen.';
  return 'Gliederung und bevorzugte Seitenadresse am Seitenzweck ausrichten. Doppelte oder widersprüchliche Angaben korrigieren und erneut prüfen.';
 }
 if(issue.area==='Sicherheit')return /zertifikat/.test(t)?'Die automatische Zertifikatsverlängerung beim Hosting prüfen und einen rechtzeitigen Ablaufalarm einrichten. Nach der Verlängerung die neue Laufzeit kontrollieren.':/http|unverschlüsselt|ressourcen/.test(t)?'Seite und betroffene Ressourcen auf HTTPS umstellen. Interne Verweise aktualisieren und anschließend prüfen, ob weiterhin unverschlüsselte Inhalte geladen werden.':'Die fehlende Schutzrichtlinie mit dem Hosting-Verantwortlichen passend zur Website konfigurieren. Änderungen zunächst testen, damit Formulare und eingebundene Dienste weiter funktionieren.';
 if(issue.area==='Formulare')return /mail/.test(t)?'Das betreffende E-Mail-Feld als E-Mail-Eingabe konfigurieren. Leere und ungültige Angaben testen und eine verständliche Fehlermeldung bereitstellen.':/beschrift/.test(t)?'Jedes betroffene Feld mit einer sichtbaren und technisch zugeordneten Beschriftung versehen. Danach Tastaturbedienung und Ausgabe mit Hilfsmitteln prüfen.':'Die betroffenen Formularregeln bzw. Zieladressen korrigieren. Pflichtfelder, ungültige Eingaben und verständliche Fehlermeldungen in einem abgestimmten Test prüfen.';
 if(issue.area==='Medien')return /pdf/.test(t)?'Das PDF aus einer strukturierten Quelldatei neu exportieren. Dokumenttitel, Sprache und Tags hinterlegen; Lesereihenfolge und Formularfelder anschließend fachlich prüfen.':/untertitel|video/.test(t)?'Passende Untertitel bereitstellen und auf inhaltliche Richtigkeit prüfen. Den Player anschließend per Tastatur bedienen und wichtige Bildinformationen berücksichtigen.':'Eine gut erreichbare Textalternative ergänzen und die Medienbedienung per Tastatur und mit Hilfsmitteln prüfen.';
 return fallback;
}
