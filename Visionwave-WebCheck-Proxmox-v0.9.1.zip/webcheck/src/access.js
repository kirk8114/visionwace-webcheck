import {createHash,timingSafeEqual} from 'node:crypto';
const digest=value=>createHash('sha256').update(value).digest();
export function accessConfig(env=process.env){
 const origin=env.WEBCHECK_ORIGIN;
 if(!origin)return {remote:false};
 const parsed=new URL(origin);
 if(!['http:','https:'].includes(parsed.protocol)||parsed.username||parsed.password||parsed.origin!==origin)throw new Error('WEBCHECK_ORIGIN muss ein exakter HTTP(S)-Ursprung ohne Pfad sein.');
 if(!env.WEBCHECK_USER||!env.WEBCHECK_PASSWORD||env.WEBCHECK_PASSWORD.length<20)throw new Error('Serverbetrieb benötigt Benutzer und Passwort mit mindestens 20 Zeichen.');
 return {remote:true,origin,host:parsed.host,user:env.WEBCHECK_USER,password:env.WEBCHECK_PASSWORD};
}
export function checkAccess(req,config){
 const host=req.headers.host;
 const local=host&&['localhost','127.0.0.1','[::1]'].some(h=>host===h||host.startsWith(h+':'));
 if(!host||!(config.remote?host===config.host||local:local))return 403;
 if(req.headers['sec-fetch-site']==='cross-site')return 403;
 if(req.headers.origin&&req.headers.origin!==(config.remote?config.origin:`http://${host}`))return 403;
 // Liveness only, no scans or customer data exposed to container health probes.
 if(config.remote&&req.url==='/api/health'&&req.method==='GET')return 200;
 if(config.remote){
  const auth=req.headers.authorization||'';
  if(!auth.startsWith('Basic '))return 401;
  const actual=Buffer.from(auth.slice(6),'base64').toString('utf8');
  if(!timingSafeEqual(digest(actual),digest(`${config.user}:${config.password}`)))return 401;
 }
 return 200;
}
