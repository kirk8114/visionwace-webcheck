import {PDFDocument,rgb,PDFName} from 'pdf-lib';
import fontkit from '@pdf-lib/fontkit';
import {performanceRows} from './performance-table.js';
import {customerReportView,actionFor} from './customer-report.js';
import {trafficLight,customerFinding,areaNames,areaAdvice,plainNote,customerGroups,findingPriority} from './customer-text.js';
import {readFile} from 'node:fs/promises';
import path from 'node:path';
import {fileURLToPath} from 'node:url';
const assets=path.resolve(path.dirname(fileURLToPath(import.meta.url)),'../assets');
const labels={consumer:'BFSG: Angebot für Verbraucher',contract:'BFSG: Online-Kauf oder Buchung im Hinblick auf Verbrauchervertrag',other:'BFSG: Andere erfasste Dienstleistung',micro:'BFSG: Kleinstunternehmen-Kriterien',info:'BFSG: Informationen zur Barrierefreiheit',keyboard:'WCAG: Tastaturbedienung geprüft',reader:'WCAG: Screenreader-Test',mobile:'WCAG: Mobile Darstellung, Zoom und Umbruch',privacy:'DSGVO: Datenschutzhinweise und Dienste abgeglichen',withdraw:'DSGVO/TDDDG: Ablehnung, Auswahl und Widerruf geprüft',contracts:'DSGVO: Rechtsgrundlagen, Verträge und Drittlandübermittlungen geprüft',imprint:'Impressum: Anbieterkennzeichnung und Kontaktangaben geprüft'};
export async function exportPdf(report,options={}){
 report=customerReportView(report);
 const doc=await PDFDocument.create();doc.registerFontkit(fontkit);
 const template=await PDFDocument.load(await readFile(path.join(assets,'letterhead.pdf')));
 const background=await doc.embedPng(await readFile(path.join(assets,'letterhead.png')));
 const logo=await doc.embedPng(await readFile(path.join(assets,'../public/brand/logo.png')));
 const normal=await doc.embedFont(await readFile(path.join(assets,'DejaVuSans.ttf')),{subset:true});
 const bold=await doc.embedFont(await readFile(path.join(assets,'DejaVuSans-Bold.ttf')),{subset:true});
 const chars=new Set(normal.getCharacterSet());
 const clean=value=>Array.from(String(value??'').replace(/[\u0000-\u0008\u000b-\u001f\u007f]/g,'').replace(/[\u2010-\u2015]/g,'-')).map(c=>c==='\n'||chars.has(c.codePointAt(0))?c:'?').join('');
 const {width,height}=template.getPage(0).getSize();
 const left=46,maxWidth=width-92,bottom=132;
 const ink=rgb(.12,.17,.23),cyan=rgb(0,.39,.49),muted=rgb(.32,.38,.43);
 let page,y,currentSection,continuation=false;
 const contents=[];
 function chapter(label){currentSection=label;newPage(false,true);contents.push({label,page});page.drawRectangle({x:left,y:y+28,width:44,height:4,color:cyan});text(label,{size:21,font:bold,color:cyan,after:28});}
 function newPage(isCover=false,isChapter=false){page=doc.addPage([width,height]);page.drawImage(background,{x:0,y:0,width,height});page.drawRectangle({x:350,y:height-184,width:width-350,height:140,color:rgb(1,1,1)});y=height-140;if(currentSection&&!isChapter)page.drawText(currentSection+' - Fortsetzung',{x:left,y:height-115,font:normal,size:8,color:muted});}
 function ensure(space){if(y-space<bottom)newPage();}
 function lines(value,font,size,limit=maxWidth){
  const result=[];
  for(const paragraph of clean(value).split('\n')){
   let line='';for(const word of paragraph.split(/\s+/).filter(Boolean)){
    if(font.widthOfTextAtSize(word,size)>limit){if(line){result.push(line);line='';}let part='';for(const c of word){if(font.widthOfTextAtSize(part+c,size)>limit){result.push(part);part=c;}else part+=c;}line=part;}
    else if(line&&font.widthOfTextAtSize(line+' '+word,size)>limit){result.push(line);line=word;}else line+=(line?' ':'')+word;
   }result.push(line);
  }return result;
 }
 function text(value,{size=10,font=normal,color=ink,after=10}={}){for(const line of lines(value,font,size)){ensure(size*1.45);page.drawText(line,{x:left,y,font,size,color});y-=size*1.45;}y-=after;}
 function boxHeight(value){return 45+lines(value,normal,10,maxWidth-32).length*14.5;}
 function infoBox(label,value,kind='meaning'){
  const fill=kind==='meaning'?rgb(.92,.97,.98):rgb(.99,.94,.97);
  const accent=kind==='meaning'?cyan:rgb(.62,.13,.39);
  const remaining=lines(value,normal,10,maxWidth-32);
  let continued=false;
  while(remaining.length){
   ensure(74);
   const count=Math.max(1,Math.floor((y-bottom-45)/14.5));
   const chunk=remaining.splice(0,count),h=45+chunk.length*14.5;
   page.drawRectangle({x:left,y:y-h,width:maxWidth,height:h,color:fill});
   page.drawRectangle({x:left,y:y-h,width:3,height:h,color:accent});
   page.drawText(label+(continued?' (Fortsetzung)':''),{x:left+16,y:y-22,font:bold,size:10,color:accent});
   let ty=y-43;
   for(const line of chunk){page.drawText(line,{x:left+16,y:ty,font:normal,size:10,color:ink});ty-=14.5;}
   y-=h+12;
   if(remaining.length){newPage();continued=true;}
  }
 }
 function heading(value,before=16){y-=before;const titleLines=lines(value,bold,12);ensure(titleLines.length*17.4+48);text(value,{size:12,font:bold,color:cyan,after:14});}
 const when=new Date(report.createdAt).toLocaleDateString('de-DE',{timeZone:'Europe/Berlin'});
 const title=clean(options.title||'Website-Prüfbericht').slice(0,200);
 doc.setTitle(title);doc.setAuthor('Visionwave Media');doc.setSubject('Verständlicher Kundenbericht mit Ampelübersicht');doc.setCreator('Visionwave Media WebCheck 0.9.1');
 const issues=(report.issues||[]).filter(i=>i.area!=='GoBD'),areas=['Impressum','DSGVO','WCAG','BFSG',...(report.extended?['Performance','SEO','Links','Sicherheit','Formulare','Medien'].filter(a=>report.extended.categories[a]?.length):[])];
 const groups=customerGroups(issues);
 const priorities=issues.map(findingPriority);
 const lights=Object.fromEntries(areas.map(area=>[area,trafficLight(report,area)]));
 const colors={red:rgb(.72,.12,.16),yellow:rgb(.62,.40,0),green:rgb(.10,.44,.25),gray:rgb(.40,.43,.46)};
 const shorten=(value,max)=>{const t=plainNote(value);return t.length>max?t.slice(0,max-3)+'...':t;};
 // Cover and contents are reserved first; links are populated after pagination.
 newPage(true);const cover=page;
 const logoWidth=430;cover.drawImage(logo,{x:(width-logoWidth)/2,y:height-185,width:logoWidth,height:logo.height*logoWidth/logo.width});
 // Editorial cover: generous white space, typography and one restrained brand accent.
 const coverItems=[];let centerCover=true;
 const coverText=(value,at,{size=11,font=normal,color=ink,limit=maxWidth}={})=>{
  for(const line of lines(value,font,size,limit)){const item={line,at,size,font,color};if(centerCover)coverItems.push(item);else cover.drawText(line,{x:left,y:at,size,font,color});at-=size*1.45;}return at;
 };

 coverText('WEBSITE-ANALYSE',605,{size:10,font:bold,color:cyan});
 const coverTitle=shorten(title,100);let coverSize=30;
 while(lines(coverTitle,bold,coverSize).length>3&&coverSize>20)coverSize--;
 let coverY=coverText(coverTitle,564,{size:coverSize,font:bold});
 coverY-=22;coverY=coverText('Ergebnisse und Handlungsempfehlungen',coverY,{size:13,color:muted});
 coverY-=50;
 if(options.customer){coverY=coverText('ERSTELLT FÜR',coverY,{size:9,font:bold,color:cyan});coverY=coverText(shorten(options.customer,90),coverY-12,{size:15,font:bold});}
 if(options.project)coverY=coverText(shorten(options.project,90),coverY-10,{size:11,color:muted});
 coverY=coverText(shorten(report.url,100),coverY-15,{size:11,color:muted});
 const blockBottom=Math.min(...coverItems.map(item=>item.at-item.size*.2));
 const offset=((height-185)+195)/2-(638+blockBottom)/2;
 cover.drawRectangle({x:left,y:634+offset,width:54,height:4,color:cyan});
 for(const item of coverItems)cover.drawText(item.line,{x:left,y:item.at+offset,size:item.size,font:item.font,color:item.color});centerCover=false;
 cover.drawLine({start:{x:left,y:195},end:{x:width-left,y:195},thickness:1,color:rgb(.82,.89,.91)});
 coverText(`Prüfdatum: ${when}`,171,{size:10});
 coverText('Websitequalität, Datenschutz und Barrierefreiheit',146,{size:9,color:muted});
 newPage();const tocPages=[page];if(report.extended||report.comparison){newPage();tocPages.push(page);}
 chapter('Ihre Website auf einen Blick');text('Ergebnisübersicht', {size:10,color:muted,after:9});
 if(options.customer)text('Kunde: '+shorten(options.customer,90),{font:bold,size:9,after:3});
 if(options.project)text('Projekt: '+shorten(options.project,90),{size:9,after:3});
 text('Website: '+shorten(report.url,100),{size:9,after:3});
 text(`Prüfdatum: ${when} | ${report.pages?.length||0} ${report.pages?.length===1?'Seite':'Seiten'} untersucht`,{size:9,after:8});
 text(`${issues.filter(i=>i.status==='Mangel').length} Mängel | ${issues.filter(i=>i.status!=='Mangel').length} Hinweise / offene Punkte | ${groups.length} Themen`,{size:9,after:6});
 text('Die Ampel zeigt Handlungsbedarf und offene Prüfungen. Sie ist keine Bestätigung vollständiger gesetzlicher Konformität.',{size:9,after:9});
 for(const area of ['Impressum','DSGVO','WCAG','BFSG'].sort((a,b)=>({red:0,yellow:1,gray:2,green:3}[lights[a].color])-({red:0,yellow:1,gray:2,green:3}[lights[b].color]))){
  const light=lights[area];ensure(69);
  page.drawCircle({x:left+5,y:y-3,size:5,color:colors[light.color]});
  page.drawText(areaNames[area],{x:left+18,y,font:bold,size:10,color:ink});y-=17;
  text(light.label.replace(/^(ROT|GELB|GRÜN) - /,'' ),{font:bold,size:9,color:colors[light.color],after:3});
  y-=14;
 }
 text('Empfohlene Reihenfolge',{font:bold,size:10,color:cyan,after:5});
 text('1. Erkannte Mängel beheben. 2. Hinweise fachlich klären. 3. Änderungen erneut prüfen und Ergebnisse dokumentieren.',{size:9,after:8});
 text('Grün: im dokumentierten Prüfumfang unauffällig. Gelb: Klärung offen. Rot: Handlungsbedarf. Farben gelten nur für den Prüfumfang. Grün ersetzt keine vollständige Prüfung.',{size:8,color:muted,after:0});
 if(report.extended){chapter('Zusätzliche Qualitätschecks');for(const area of areas.filter(a=>!['Impressum','DSGVO','WCAG','BFSG'].includes(a))){const light=lights[area];ensure(70);text(areaNames[area],{font:bold,size:11,color:cyan});text(light.label.replace(/^(ROT|GELB|GRÜN) - /,'' ),{font:bold,size:9,color:colors[light.color]});y-=18;}}
 // Each overview section starts on its own page.
 chapter('Prüfstatistik und Prioritäten');
 text('Die Zahlen beschreiben Befunde im untersuchten Umfang, keine Prozentzahl für rechtliche Konformität. Gleiche Befunde können auf mehreren Seiten auftreten.',{size:9,after:12});
 const metrics=[['Seiten untersucht',report.pages?.length||0],['Automatische Mängel',issues.filter(i=>i.status==='Mangel').length],['Hinweise / offene Punkte',issues.filter(i=>i.status!=='Mangel').length],['Zusammengefasste Themen',groups.length]];
 const cardWidth=(maxWidth-12)/2;
 for(let row=0;row<2;row++){ensure(64);for(let col=0;col<2;col++){const [label,value]=metrics[row*2+col];const x=left+col*(cardWidth+12);page.drawRectangle({x,y:y-48,width:cardWidth,height:48,color:rgb(.94,.97,.98)});page.drawText(String(value),{x:x+12,y:y-26,font:bold,size:22,color:cyan});page.drawText(label,{x:x+12,y:y-44,font:normal,size:9,color:ink});}y-=64;}
 y-=10;
 heading('Einzelbefunde nach Bearbeitungspriorität',8);
 const priorityRows=[[0,'Sehr hoch'],[1,'Hoch / zeitnah klären'],[2,'Mittel'],[3,'Niedrig'],[4,'Weitere Prüfung']];
 const maxCount=Math.max(1,...priorityRows.map(([rank])=>priorities.filter(p=>p.rank===rank).length));
 for(const [rank,label] of priorityRows){const count=priorities.filter(p=>p.rank===rank).length;ensure(21);page.drawText(label,{x:left,y,font:normal,size:9,color:ink});page.drawRectangle({x:left+180,y:y-2,width:230,height:10,color:rgb(.93,.95,.96)});if(count)page.drawRectangle({x:left+180,y:y-2,width:230*count/maxCount,height:10,color:cyan});page.drawText(String(count),{x:left+425,y,font:bold,size:9,color:ink});y-=19;}
 y-=8;heading('Einzelbefunde nach Prüfbereich',8);
 for(let row=0;row<Math.ceil(areas.length/2);row++){
  ensure(24);
  for(let col=0;col<2;col++){const area=areas[row*2+col];if(!area)continue;const x=left+col*(cardWidth+12),count=issues.filter(i=>i.area===area).length;page.drawText(areaNames[area],{x,y,font:normal,size:8,color:ink});page.drawText(String(count),{x:x+cardWidth-20,y,font:bold,size:10,color:cyan});}
  y-=22;
 }
 y-=8;
 text('Priorität beschreibt den Bearbeitungsbedarf im erfassten Prüfumfang.',{size:8,color:muted,after:0});
 chapter('Einordnung und nächste Schritte');
 heading('Was dieser Bericht für Sie bedeutet');
 text('Wir haben öffentlich erreichbare Seiten Ihrer Website automatisch untersucht und vorhandene Prüfantworten berücksichtigt. Der Bericht erklärt die erkannten Punkte und zeigt, wie Sie Ihre Website verbessern können. Rechtliche Einordnungen und die Vollständigkeit von Pflichtangaben benötigen ergänzende fachliche Prüfungen.');
 if(report.errors?.length)text('Ein Teil der Website konnte nicht vollständig geladen werden. Die Ergebnisse sind daher eingeschränkt. Die betroffenen Seiten sollten erneut geprüft werden.',{font:bold});
 if(plainNote(options.comment)){heading('Unsere Anmerkungen');text(plainNote(options.comment));}
 heading('Erkannte Analyse-, Werbe- und weitere Dienste');
 const detectedServices=[...new Set((report.pages||[]).flatMap(p=>(p.states||[]).flatMap(state=>state.services||[])))];
 text(detectedServices.length?detectedServices.join(', '):'Keine bekannten Dienste im beobachteten Netzwerkverkehr erkannt. Dies schließt andere oder serverseitige Dienste nicht aus.');
 if(report.legalChecks?.services?.comparisonPerformed)text('Die erkannten Dienste wurden mit Texttreffern in der geprüften Datenschutzerklärung verglichen. Ob die Beschreibungen rechtlich ausreichen, muss fachlich bewertet werden.',{size:9});
 else text('Der Textabgleich mit der Datenschutzerklärung ist noch offen. Dazu muss die Erklärung innerhalb des Scanumfangs untersucht werden.',{size:9});
 heading('Priorisierte Handlungsempfehlungen');
 const firstActions=groups.slice(0,5);
 if(firstActions.length){for(const [index,g] of firstActions.entries()){ensure(115);text(`${index+1}. ${g.finding.title}`,{font:bold,size:11,color:colors[g.priority.color],after:8});text(actionFor(g.issue,g.finding.fix),{size:10,after:18});}}
 else text('Die untersuchten Bereiche regelmäßig kontrollieren und Änderungen erneut prüfen. Die Ergebnisse gelten nur für den dokumentierten Prüfumfang.');
 const orderedAreas=[...areas].sort((a,b)=>Math.min(5,...groups.filter(g=>g.issue.area===a).map(g=>g.priority.rank))-Math.min(5,...groups.filter(g=>g.issue.area===b).map(g=>g.priority.rank)));
 let findingNumber=0;
 for(const area of orderedAreas){
  const light=lights[area],areaGroups=groups.filter(g=>g.issue.area===area);
  chapter(areaNames[area]);
  page.drawRectangle({x:left,y:y-48,width:maxWidth,height:52,color:rgb(.94,.97,.98)});
  page.drawCircle({x:left+15,y:y-10,size:5,color:colors[light.color]});
  page.drawText(light.label.replace(/^(ROT|GELB|GRÜN) - /,''),{x:left+30,y:y-13,font:bold,size:10,color:colors[light.color]});
  page.drawText(`${areaGroups.length} ${areaGroups.length===1?'Thema':'Themen'} | ${issues.filter(i=>i.area===area&&i.status==='Mangel').length} erkannte Mängel`,{x:left+15,y:y-34,font:normal,size:9,color:muted});y-=66;
  y-=12;
  if(!areaGroups.length)text('In diesem Bereich wurden keine automatischen Befunde erkannt. Offene ergänzende Prüfungen finden Sie am Ende dieses Kapitels.');
  for(const group of areaGroups){
   const {finding,priority,urls}=group;
   const titleText=`${++findingNumber}. ${priority.level}: ${finding.title}`;
   const blockHeight=lines(titleText,bold,12).length*17.4+36
    +lines('Betroffene Seiten: '+urls.slice(0,3).join(', '),normal,9).length*13.05+6
    +boxHeight(finding.meaning)+12
    +boxHeight(actionFor(group.issue,finding.fix))+12;
   if(blockHeight<height-140-bottom)ensure(blockHeight);
   ensure(lines(titleText,bold,12).length*17.4+36);
   page.drawRectangle({x:left-10,y:y-4,width:3,height:16,color:colors[priority.color]});
   text(titleText,{size:12,font:bold,color:colors[priority.color],after:8});
   text(`${group.count} Einzelbefunde auf ${urls.length} Seiten`,{size:8.5,color:muted});
   text('Betroffene Seiten: '+urls.slice(0,3).join(', ')+(urls.length>3?` (und ${urls.length-3} weitere)`:''),{size:9});
   infoBox('Was bedeutet das?',finding.meaning);
   infoBox('Handlungsempfehlung:',actionFor(group.issue,finding.fix),'action');
   y-=24;
  }
  if(area==='Performance'){
   const rows=performanceRows(report.extended?.performance);
   if(rows.length){
    const colWidths=[205,92,92,maxWidth-389],colX=[left,left+205,left+297,left+389];
    const rowHeight=row=>Math.max(...[row.label,row.target,row.actual,row.assessment].map((v,i)=>lines(v,normal,9,colWidths[i]-16).length))*13+18;
    ensure(100+rows.reduce((n,row)=>n+rowHeight(row),0));
    heading('Performance: Soll und Ist');
    page.drawRectangle({x:left,y:y-30,width:maxWidth,height:30,color:rgb(.94,.97,.98)});
    ['Kennzahl','Soll','Ist','Bewertung'].forEach((label,i)=>page.drawText(label,{x:colX[i]+8,y:y-19,font:bold,size:9,color:ink}));y-=30;
    for(const row of rows){const h=rowHeight(row);ensure(h+10);const values=[row.label,row.target,row.actual,row.assessment];values.forEach((value,i)=>{let ty=y-19;for(const line of lines(value,i===3?bold:normal,9,colWidths[i]-16)){page.drawText(line,{x:colX[i]+8,y:ty,font:i===3?bold:normal,size:9,color:i===3?colors[row.color]:ink});ty-=13;}});page.drawLine({start:{x:left,y:y-h},end:{x:width-left,y:y-h},thickness:.5,color:rgb(.85,.90,.92)});y-=h;}
    y-=16;text('Orientierende Labormessungen der Startseite, keine Bewertung realer Nutzerdaten. Angezeigt werden nur verfügbare Messwerte.',{size:8,color:muted});
    text('* Datenmenge: Agentur-Richtwert, kein allgemeiner Standard. Für Dokumentaufbau und Anfragezahl gibt es keinen pauschalen Sollwert.',{size:8,color:muted});
    text('LCP-/CLS-Referenz: web.dev/articles/defining-core-web-vitals-thresholds',{size:7.5,color:muted});
   }
  }
  if(area==='DSGVO'&&report.extended?.categories?.DSGVO){ensure(180);heading('Erweiterte Cookie- und Einwilligungstests');for(const result of report.extended.categories.DSGVO){ensure(75);text(result.url,{size:9,color:muted});text(result.summary,{size:9});}}
  if(!['Impressum','DSGVO','WCAG','BFSG'].includes(area)){ensure(130);heading('Prüfergebnisse und Umfang');for(const result of report.extended?.categories?.[area]||[]){ensure(85);text(result.url,{size:9,color:muted});text(result.summary,{size:10});}continue;}
  const hasSupplement=Object.entries(labels).some(([key,label])=>label.startsWith(area+':')&&(report.autoReview?.[key]||['yes','no','na'].includes(report.review?.[key])))||area==='DSGVO'&&report.autoReview?.withdraw;
  if(!hasSupplement)continue;
  ensure(180);heading('Ergänzende Prüfungen');
  const categoryKeys=Object.keys(labels).filter(key=>area==='Impressum'?key==='imprint':area==='DSGVO'?['privacy','withdraw','contracts'].includes(key):area==='WCAG'?['keyboard','reader','mobile'].includes(key):['consumer','contract','other','micro','info'].includes(key));
  text('Automatische Versuche liefern Hinweise. Eingetragene Antworten sind ergänzende Angaben und werden durch die Software nicht unabhängig bestätigt.',{size:9,color:muted});
  for(const key of categoryKeys){
   const result=report.autoReview?.[key];const answer=report.review?.[key];if(!result&&!['yes','no','na'].includes(answer))continue;ensure(110);
   text(labels[key].replace(/^[^:]+: /,''),{font:bold,size:10,after:4});
   if(result){text(result.summary,{size:9});infoBox('Handlungsempfehlung:',result.next,'action');}

   if(['yes','no','na'].includes(answer))text('Ergänzende Antwort: '+({yes:'Als geprüft / vorhanden angegeben',no:'Mit Nein beantwortet - fachlich klären',na:'Als nicht anwendbar angegeben',unknown:'Noch offen'}[report.review?.[key]]||'Noch offen'),{size:9,color:muted,after:12});
  }
 }
 if(report.comparison?.comparable){chapter('Vergleich mit der vorherigen Prüfung');const c=report.comparison;if(c.comparable){text('Vergleichsdatum: '+new Date(c.previousDate).toLocaleDateString('de-DE'),{size:10});text(`${c.disappeared} Befunde nicht mehr erkannt | ${c.added} neu erkannt | ${c.remaining} erneut erkannt`,{font:bold});}if(c.comparable&&c.metrics?.length){heading('Orientierende Labormesswerte');for(const m of c.metrics){const label={lcpMs:'LCP in Millisekunden',cls:'Layoutverschiebung',bytes:'Datenmenge in Bytes'}[m.key]||m.key;text(`${label}: vorher ${Math.round(m.before*1000)/1000}, jetzt ${Math.round(m.after*1000)/1000}`,{size:10});}}text(c.reason);}
 chapter('Prüfumfang und Grenzen');
 text('Die Kapitel enthalten sowohl automatisch ermittelte Hinweise als auch ergänzend eingetragene Antworten. Eine positive Antwort bestätigt nur den jeweiligen Einzelpunkt.');
 heading('Untersuchte Seiten');
 for(const entry of report.pages||[])text(shorten(entry.url,200),{size:9});

 if(plainNote(report.review?.notes)){heading('Ergänzende Prüfnotizen');text(plainNote(report.review.notes));}
 heading('Grenzen der Prüfung');
 text('Die Untersuchung umfasst eine Auswahl öffentlicher Seiten in der Desktop-Darstellung. Login-Bereiche, vollständige Kaufabläufe, mobile Darstellung und PDF-Inhalte werden nicht vollständig automatisch geprüft. Zusatzchecks nutzen Stichproben; Performancewerte entstehen im abgesicherten Scanner und sind keine vollständigen Core-Web-Vitals-Nutzerdaten. Formulare werden nicht abgeschickt. Cookie-Auswahl und externe Dienste können zusätzliche Tests benötigen.');
 text('Auch ein unauffälliges Ergebnis bedeutet nicht, dass die Website insgesamt rechtskonform oder vollständig barrierefrei ist. Nach Änderungen empfehlen wir eine erneute Prüfung.');
 text(`Prüfdatum: ${when} | Prüfversion: ${report.ruleVersion}`,{size:8,color:muted});
 const pages=doc.getPages();currentSection=undefined;
 let tocIndex=0;page=tocPages[tocIndex];y=height-140;
 text('Inhaltsverzeichnis',{size:23,font:bold,color:cyan,after:14});
 text('Ihr Weg vom Überblick zu konkreten Verbesserungen.',{size:10,color:muted,after:25});
 contents.forEach((entry,index)=>{
  if(y<bottom+65&&tocIndex+1<tocPages.length){page=tocPages[++tocIndex];y=height-140;text('Inhaltsverzeichnis - Fortsetzung',{size:20,font:bold,color:cyan,after:25});}
  const number=pages.indexOf(entry.page)+1;
  const label=`${String(index+1).padStart(2,'0')}  ${entry.label}`;
  const wrapped=lines(label,bold,11,maxWidth-45),top=y;
  for(const line of wrapped){page.drawText(line,{x:left,y,font:bold,size:11,color:ink});y-=17;}
  page.drawText(String(number),{x:width-left-20,y:top,font:bold,size:11,color:cyan});
  page.drawLine({start:{x:left,y:y-4},end:{x:width-left,y:y-4},thickness:.6,color:rgb(.85,.90,.92)});
  const annotation=doc.context.register(doc.context.obj({Type:'Annot',Subtype:'Link',Rect:[left,y-4,width-left,top+13],Border:[0,0,0],A:{Type:'Action',S:'GoTo',D:[entry.page.ref,PDFName.of('Fit')]}}));
  const annotations=page.node.Annots();if(annotations)annotations.push(annotation);else page.node.set(PDFName.of('Annots'),doc.context.obj([annotation]));
  y-=22;
 });
 y-=18;text('So lesen Sie den Bericht',{font:bold,size:11,color:cyan});
 text('Rot: erkannter Handlungsbedarf. Gelb: offene Klärung. Grün: im dokumentierten Prüfumfang unauffällig. Die Kapitel mit dem höchsten Bearbeitungsbedarf stehen zuerst.',{size:9});
 text('Die Einträge im Inhaltsverzeichnis sind anklickbar. Jeder Prüfbereich enthält Befunde, Verbesserungsvorschläge und ergänzende Prüfungen.',{size:9,color:muted});
pages.forEach((p,index)=>{const footer=`Visionwave Media WebCheck | Seite ${index+1} von ${pages.length}`;p.drawText(footer,{x:(width-normal.widthOfTextAtSize(footer,8))/2,y:105,size:8,font:normal,color:muted});});
 return doc.save();
}
