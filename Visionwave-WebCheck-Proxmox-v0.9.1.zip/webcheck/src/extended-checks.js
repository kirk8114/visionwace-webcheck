import {PDFDocument,PDFName,PDFDict} from 'pdf-lib';
const finding=(area,status,title,detail,url,impact='moderate')=>({area,status,title,detail,url,impact,evidence:[],rule:''});
export async function inspectExtendedPage(page){
 return page.evaluate(()=>{
  const meta=name=>document.querySelector(`meta[name="${name}"]`)?.content||'';
  const links=[...document.querySelectorAll('a[href]')].map(a=>({url:a.href,text:(a.textContent||'').trim().slice(0,100)}));
  const forms=[...document.forms].slice(0,12).map(f=>{
   const fields=[...f.elements].filter(e=>['INPUT','SELECT','TEXTAREA'].includes(e.tagName)&&!['hidden','submit','button','reset'].includes(e.type));
   return {method:f.method,action:f.action,count:fields.length,required:fields.filter(e=>e.required).length,noValidate:f.noValidate,
    missingLabels:fields.filter(e=>!(e.labels?.length||e.getAttribute('aria-label')||e.getAttribute('aria-labelledby')||e.title)).length,
    emailWithoutType:fields.filter(e=>/mail/i.test(e.name+' '+e.id)&&e.type!=='email').length,
    requiredWithoutConstraint:fields.filter(e=>e.required&&e.willValidate===false).length,
    validationProbes:fields.filter(e=>e.required||e.type==='email').map(e=>{const c=e.cloneNode(true);c.value=e.required?'':'webcheck-invalid';return {type:e.type,required:e.required,invalidDetected:!c.checkValidity()};}),
    errorsLinked:fields.filter(e=>e.getAttribute('aria-describedby')||e.getAttribute('aria-errormessage')).length};
  });
  const media=[...document.querySelectorAll('video,audio')].slice(0,15).map(e=>({type:e.tagName.toLowerCase(),captions:[...e.querySelectorAll('track')].some(t=>['captions','subtitles'].includes(t.kind)),controls:e.controls}));
  const images=[...document.images].filter(e=>e.naturalWidth>0).map(e=>({url:e.currentSrc.split('?')[0],natural:e.naturalWidth,display:e.clientWidth}));
  const ld=[...document.querySelectorAll('script[type="application/ld+json"]')].map(e=>{try{JSON.parse(e.textContent);return true;}catch{return false;}});
  const anchors=links.filter(l=>{try{const u=new URL(l.url);return u.origin===location.origin&&u.pathname===location.pathname&&u.hash;}catch{return false;}}).map(l=>{try{const hash=decodeURIComponent(new URL(l.url).hash.slice(1));return {url:l.url,exists:!!(document.getElementById(hash)||document.getElementsByName(hash).length)||hash==='top'};}catch{return {url:l.url,exists:false};}});
  return {externalPlayers:[...document.querySelectorAll('iframe[src]')].filter(e=>/youtube|vimeo/i.test(e.src)).length,title:document.title,description:meta('description'),robots:meta('robots'),canonical:document.querySelector('link[rel="canonical"]')?.href||'',h1:document.querySelectorAll('h1').length,ld,links,anchors,forms,media,images,transcriptHint:/transkript|transcript/i.test(document.body.innerText),insecure:[...document.querySelectorAll('script[src],img[src],iframe[src],link[href]')].map(e=>e.src||e.href).filter(u=>u.startsWith('http:'))};
 });
}
export function analyzeExtendedPage(entry){
 const x=entry.extendedProbe;if(!x)return [];
 const out=[],url=entry.url,h=entry.responseHeaders||{};
 const add=(a,t,d,status='Verdacht',impact='moderate')=>out.push(finding(a,status,t,d,url,impact));
 if(!x.title.trim())add('SEO','Seitentitel fehlt','Einen eindeutigen Titel ergänzen.','Mangel');
 if(!x.description.trim())add('SEO','Suchergebnis-Beschreibung fehlt','Eine passende Beschreibung für das Suchergebnis ergänzen.');
 if(x.h1!==1)add('SEO','Hauptüberschrift prüfen',`${x.h1} Hauptüberschriften erkannt. Gliederung und Seitenzweck bewerten.`);
 if(/noindex|none/i.test(x.robots+' '+(h['x-robots-tag']||'')))add('SEO','Indexierung wird eingeschränkt','Eine noindex-Anweisung wurde erkannt. Prüfen, ob diese Seite in Suchmaschinen erscheinen soll.');
 if(!x.canonical)add('SEO','Bevorzugte Seitenadresse prüfen','Keine Canonical-Angabe erkannt. Bedarf und doppelte Inhalte prüfen.');
 if(x.ld.some(v=>!v))add('SEO','Strukturierte Daten enthalten ungültiges JSON','Strukturierte Daten lassen sich nicht vollständig lesen.','Mangel');
 if(new URL(url).protocol!=='https:')add('Sicherheit','Website verwendet HTTP','Verschlüsselte HTTPS-Verbindung einrichten.','Mangel','serious');
 if(new URL(url).protocol==='https:'&&x.insecure.length)add('Sicherheit','Unsichere Ressourcen eingebunden',`${x.insecure.length} HTTP-Verweise in Ressourcen erkannt. Tatsächliche Ladung und HTTPS-Alternativen prüfen.`);
 for(const [key,name] of [['content-security-policy','Inhaltssicherheitsrichtlinie'],['strict-transport-security','HTTPS-Erzwingung'],['x-content-type-options','Schutz vor Inhaltstyp-Verwechslung'],['referrer-policy','Weitergabe der Herkunftsadresse']])if(!h[key])add('Sicherheit',name+' prüfen','Der zugehörige Sicherheitsheader fehlt. Eine zum Angebot passende Konfiguration fachlich prüfen.');
 if(entry.tls?.validTo){const days=Math.floor((Date.parse(entry.tls.validTo)-Date.now())/86400000);if(days<30)add('Sicherheit','Zertifikat läuft bald ab',`Restlaufzeit ungefähr ${days} Tage. Verlängerung prüfen.`);}
 for(const a of x.anchors.filter(a=>!a.exists))out.push(finding('Links','Verdacht','Sprungziel nicht gefunden','Ein interner Sprungverweis hat kein erkanntes Ziel. Dynamische Inhalte berücksichtigen.',a.url));
 x.forms.forEach((f,i)=>{if(f.missingLabels)add('Formulare','Formularfelder ohne klare Beschriftung',`Formular ${i+1}: ${f.missingLabels} Felder ohne erkannte Beschriftung. Sichtbare und zugängliche Namen ergänzen.`,'Mangel');if(f.emailWithoutType)add('Formulare','E-Mail-Eingaben prüfen',`Formular ${i+1}: ${f.emailWithoutType} mögliche E-Mail-Felder ohne E-Mail-Eingabetyp.`);if(f.noValidate)add('Formulare','Formularvalidierung fachlich prüfen',`Formular ${i+1} deaktiviert die Browservalidierung. Eigene Fehlermeldungen und serverseitige Prüfung testen.`);if(new URL(url).protocol==='https:'&&f.action.startsWith('http:'))add('Formulare','Formularziel ist unverschlüsselt','Die Zieladresse verwendet HTTP. Übermittlung und tatsächlichen Ablauf prüfen.','Mangel','serious');});
 if(x.media.some(m=>m.type==='audio')&&!x.transcriptHint)add('Medien','Transkript für Audio prüfen','Kein eindeutiger Transkripthinweis erkannt. Eine gleichwertige Textalternative fachlich prüfen.');
 if(x.externalPlayers)add('Medien','Externe Mediaplayer ergänzend prüfen',`${x.externalPlayers} externe Video-Player erkannt. Untertitel, Steuerung und mögliche Textalternativen im Player fachlich testen.`,'Manuell prüfen');
 x.media.forEach(m=>{if(m.type==='video'&&!m.captions)add('Medien','Untertitel für Video prüfen','Kein Untertitel-Track erkannt. Inhalt, Ton und mögliche externe Untertitel prüfen.');if(!m.controls)add('Medien','Medienbedienung prüfen','Keine nativen Bedienelemente erkannt. Individuelle Bedienung per Tastatur und Hilfsmitteln testen.');});
 return out;
}
export function analyzePerformance(samples,url){
 const good=samples.filter(s=>s.ok);const median=key=>{const a=good.map(s=>s[key]).filter(v=>Number.isFinite(v)).sort((a,b)=>a-b);return a.length?a[Math.floor(a.length/2)]:null;};
 const result={runs:samples.length,successfulRuns:good.length,lcpMs:median('lcpMs'),cls:median('cls'),domMs:median('domMs'),bytes:median('bytes'),requests:median('requests'),issues:[]};
 if(result.lcpMs>2500)result.issues.push(finding('Performance','Verdacht','Hauptinhalt erscheint langsam',`Orientierende LCP-Labormessung: ${Math.round(result.lcpMs)} ms. Bildgrößen, Serverantwort und blockierende Ressourcen prüfen.`,url));
 if(result.cls>0.1)result.issues.push(finding('Performance','Verdacht','Layout verschiebt sich beim Laden',`Beobachtete Layoutverschiebung: ${result.cls.toFixed(3)}. Platz für Bilder und nachgeladene Inhalte reservieren.`,url));
 if(result.bytes>2*1024*1024)result.issues.push(finding('Performance','Verdacht','Große Datenmenge beim Seitenaufruf',`Etwa ${(result.bytes/1048576).toFixed(1)} MB in einem Labordurchlauf. Bilder und Skripte optimieren.`,url));
 return result;
}
export async function inspectPdf(body,url){
 try{const p=await PDFDocument.load(body);const tagged=p.catalog.get(PDFName.of('StructTreeRoot')) instanceof PDFDict||!!p.catalog.get(PDFName.of('StructTreeRoot'));const lang=!!p.catalog.get(PDFName.of('Lang'));const title=!!p.getTitle();const issues=[];
  if(!tagged||!lang||!title)issues.push(finding('Medien','Verdacht','PDF-Zugänglichkeit prüfen',`Dokument mit ${p.getPageCount()} Seiten: ${!tagged?'keine Strukturkennzeichnung erkannt; ':''}${!lang?'Dokumentsprache fehlt; ':''}${!title?'Dokumenttitel fehlt; ':''}Lesereihenfolge und Bedienung ergänzend prüfen.`,url));
  return {url,pages:p.getPageCount(),tagged,lang,title,issues,summary:`PDF: ${p.getPageCount()} Seiten; Struktur ${tagged?'erkannt':'nicht erkannt'}, Sprache ${lang?'erkannt':'nicht erkannt'}, Titel ${title?'erkannt':'nicht erkannt'}. Kein vollständiger Barrierefreiheitsnachweis.`};
 }catch{return {url,issues:[finding('Medien','Manuell prüfen','PDF konnte nicht geprüft werden','Verschlüsselung, Format oder Ladeumfang verhindern die automatische Prüfung.',url)],summary:'PDF-Inhalt nicht automatisch prüfbar.'};}
}
export async function runAuxiliaryChecks(report,fetchSafe,{deadline=Infinity,maxLinks=40,maxPdfs=5}={}){
 const origin=new URL(report.url).origin,links=[...new Set(report.pages.flatMap(p=>p.extendedProbe?.links||[]).map(l=>l.url))];
 const candidates=links.filter(u=>{try{const x=new URL(u);return x.origin===origin&&!x.search&&!x.hash&&!/logout|delete|remove|abmelden|unsubscribe|optout/i.test(x.pathname);}catch{return false;}});
 const results=[],pdfs=[],issues=[];let truncated=false;
 const selected=candidates.slice(0,maxLinks);for(const url of selected){if(Date.now()>deadline-4000){truncated=true;break;}
  try{const r=await fetchSafe(url);results.push({url,status:r.status,redirects:r.redirects||0});if(r.status>=400)issues.push(finding('Links','Mangel','Verlinkte Seite nicht erreichbar',`HTTP ${r.status}. Zieladresse korrigieren oder veralteten Link entfernen.`,url));if(r.redirects>1)issues.push(finding('Links','Verdacht','Mehrfache Weiterleitung erkannt',`${r.redirects} Weiterleitungen. Möglichst direkt auf die endgültige Adresse verlinken.`,url));if(pdfs.length<maxPdfs&&(/\.pdf$/i.test(new URL(url).pathname)||/application\/pdf/i.test(r.headers['content-type']||''))){const p=await inspectPdf(r.body,url);pdfs.push(p);issues.push(...p.issues);}}
  catch(e){results.push({url,error:e.message});issues.push(finding('Links','Verdacht','Linkprüfung nicht erfolgreich','Das Ziel konnte innerhalb des abgesicherten Prüfumfangs nicht geladen werden. Erreichbarkeit manuell prüfen.',url));}
 }
 const discovery={};for(const name of ['robots.txt','sitemap.xml']){if(Date.now()>deadline-4000){discovery[name]={error:'Zeitbudget'};continue;}try{const r=await fetchSafe(new URL('/'+name,report.url).href);discovery[name]={status:r.status,exists:r.status===200,valid:name==='robots.txt'?/user-agent|sitemap/i.test(r.body.toString('utf8')):/<urlset\b|<sitemapindex\b/i.test(r.body.toString('utf8'))};}catch(e){discovery[name]={error:e.message};}}
 if(!discovery['sitemap.xml']?.valid)issues.push(finding('SEO','Manuell prüfen','Sitemap nicht an Standardadresse erkannt','Sitemap kann anders liegen oder über robots.txt bzw. Search Console angegeben sein. Auffindbarkeit und Inhalt prüfen.',report.url));
 return {links:{tested:results.length,available:candidates.length,truncated:truncated||candidates.length>maxLinks,results},pdfs,discovery,issues};
}
export function compareReports(current,previous){
 if(!previous)return {comparable:false,reason:'Noch kein früherer Bericht für diese Website vorhanden.'};
 const samePages=JSON.stringify(current.pages.map(p=>p.url).sort())===JSON.stringify(previous.pages.map(p=>p.url).sort());
 if(current.ruleVersion!==previous.ruleVersion||current.scope.maxPages!==previous.scope.maxPages||!samePages||current.errors.length||previous.errors.length||current.coverage?.complete===false||previous.coverage?.complete===false||[current,previous].some(r=>r.pages.some(p=>p.states?.some(s=>s.blocked?.length))))return {comparable:false,previousId:previous.id,reason:'Prüfversion, untersuchte Seiten oder Vollständigkeit unterscheiden sich. Ergebnisse sind nicht zuverlässig vergleichbar.'};
 const key=i=>[i.area,i.status,i.title,i.url,i.rule].join('|');const counts=r=>{const m=new Map();for(const i of r.issues)m.set(key(i),(m.get(key(i))||0)+1);return m;};const a=counts(current),b=counts(previous);let disappeared=0,added=0;for(const k of new Set([...a.keys(),...b.keys()])){added+=Math.max(0,(a.get(k)||0)-(b.get(k)||0));disappeared+=Math.max(0,(b.get(k)||0)-(a.get(k)||0));}
 const metrics=['lcpMs','cls','bytes'].filter(key=>Number.isFinite(current.extended?.performance?.[key])&&Number.isFinite(previous.extended?.performance?.[key])).map(key=>({key,before:previous.extended.performance[key],after:current.extended.performance[key],difference:current.extended.performance[key]-previous.extended.performance[key]}));
 return {comparable:true,metrics,previousId:previous.id,previousDate:previous.createdAt,added,disappeared,remaining:current.issues.length-added,reason:'Nicht mehr erkannte Befunde sind kein unabhängiger Nachweis einer erfolgreichen Behebung. Performancewerte bleiben orientierende Labormessungen.'};
}
