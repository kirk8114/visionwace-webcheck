import dns from 'node:dns/promises';
import http from 'node:http';
import https from 'node:https';
import ipaddr from 'ipaddr.js';

export function publicAddress(address) {
  try { let ip = ipaddr.parse(address); if (ip.kind() === 'ipv6' && ip.isIPv4MappedAddress()) ip = ip.toIPv4Address(); return ip.range() === 'unicast'; } catch { return false; }
}
export function normalizeUrl(input) {
  const url = new URL(input);
  if (!['https:', 'http:'].includes(url.protocol) || url.username || url.password || (url.port && !['80','443'].includes(url.port))) throw new Error('Nur öffentliche HTTP(S)-Adressen mit Standardport und ohne Zugangsdaten sind erlaubt.');
  url.hash = ''; return url;
}
export async function resolveTarget(input, testOrigin) {
  const url = testOrigin && new URL(input).origin === testOrigin ? new URL(input) : normalizeUrl(input);
  if (testOrigin && url.origin === testOrigin) return {url, address:'127.0.0.1', family:4};
  const host = url.hostname.replace(/^\[|\]$/g,'');
  const addresses = await dns.lookup(host, {all:true, verbatim:true});
  if (!addresses.length || addresses.some(a => !publicAddress(a.address))) throw new Error('Private, lokale und reservierte Netzwerkziele sind gesperrt.');
  return {url, ...addresses[0]};
}
// Every HTTP request is pinned to its validated DNS address, including redirects.
export async function fetchPinned(input, headers = {}, testOrigin, options={}) {
  const target = await resolveTarget(input, testOrigin);
  return new Promise((resolve, reject) => {
    const transport = target.url.protocol === 'https:' ? https : http;
    const clean = {...headers, 'accept-encoding':'identity'};
    for (const key of Object.keys(clean)) if (['host','connection','content-length','transfer-encoding','proxy-authorization'].includes(key.toLowerCase())) delete clean[key];
    const req = transport.request(target.url, {method:'GET', headers:clean, lookup:(_host,opts,cb)=>opts?.all ? cb(null,[{address:target.address,family:target.family}]) : cb(null,target.address,target.family), timeout:Math.min(15000,options.timeoutMs||15000)}, res => {
      const parts=[]; let bytes=0;
      res.on('data', chunk=> {bytes+=chunk.length; if(bytes>8*1024*1024) req.destroy(new Error('Antwort überschreitet 8 MB.')); else parts.push(chunk);});
      res.on('end',()=>{const c=req.socket?.getPeerCertificate?.();resolve({status:res.statusCode,headers:res.headers,body:Buffer.concat(parts),tls:c?.valid_to?{validTo:c.valid_to,authorized:req.socket.authorized}:null});});
      res.on('error',reject);
    });
    const wallTimer=setTimeout(()=>req.destroy(new Error('Netzwerk-Gesamtzeitlimit überschritten.')),Math.min(15000,options.timeoutMs||15000));req.once('close',()=>clearTimeout(wallTimer));
    req.on('timeout',()=>req.destroy(new Error('Netzwerk-Zeitlimit überschritten.')));
    req.on('error',reject); req.end();
  });
}
