import axe from 'axe-core';
import {mentionedServices} from './services.js';
const make=(status,summary,next,evidence=[])=>({status,summary,next,evidence});
export async function probePage(page,accessibility){
 const signals=await page.evaluate(()=>{
  const body=(document.body?.innerText||'').slice(0,150000);
  const links=Array.from(document.querySelectorAll('a[href]')).map(a=>({text:(a.textContent||'').trim(),href:a.href}));
  const has=re=>re.test(body);
  return {imprint:links.some(a=>/impressum|legal notice/i.test(a.text+' '+a.href)),consumer:has(/verbraucher|privatkunden|kundenkonto|warenkorb|jetzt kaufen/i),contract:has(/warenkorb|zur kasse|jetzt kaufen|zahlungspflichtig|termin buchen|jetzt buchen/i),other:has(/bankdienstleistung|personenbeförderung|e-book|ebook/i),info:links.some(a=>/barrierefrei|accessibility/i.test(a.text+' '+a.href))||has(/erklärung zur barrierefreiheit|informationen zur barrierefreiheit/i),privacy:links.some(a=>/datenschutz|privacy/i.test(a.text+' '+a.href)),withdraw:has(/einwilligung widerrufen|cookie-einstellungen|datenschutzeinstellungen/i),contracts:has(/auftragsverarbeitung|drittland|standardvertragsklauseln|rechtsgrundlage/i),documentInfo:{imprint:/impressum|legal.notice/i.test(location.pathname+' '+document.title),privacy:/datenschutz|privacy/i.test(location.pathname+' '+document.title),imprintSignals:{operator:has(/inhaber|anbieter|vertret|verantwortlich|name|gmbh|gesellschaft|e\.v\./i),address:has(/\b\d{5}\b/)&&has(/straße|strasse|str\.|weg|platz|allee|gasse/i),email:/[^\s@]+@[^\s@]+\.[a-z]{2,}/i.test(body)},privacySignals:{controller:has(/verantwortlich|verantwortlicher/i),purposes:has(/zweck|verarbeitung/i),basis:has(/rechtsgrundlage|art(?:ikel)?\.?\s*6/i),retention:has(/speicher|aufbewahrung|lösch/i),rights:has(/auskunft|berichtigung|datenübertragbarkeit|widerspruch/i)},declaredText:/datenschutz|privacy/i.test(location.pathname+' '+document.title)?body:''}};
 });
 const focus=[];await page.keyboard.press('Escape');
 for(let i=0;i<30;i++){
  await page.keyboard.press('Tab');
  const state=await page.evaluate(()=>{const el=document.activeElement;const r=el?.getBoundingClientRect();return {tag:el?.tagName||'',visible:!!r&&r.width>0&&r.height>0,body:el===document.body};});focus.push(state);
 }
 let treeAvailable=false;
 try{treeAvailable=(await page.locator('body').ariaSnapshot({timeout:3000})).length>0;}catch{}
 const desktop=page.viewportSize();let mobile;
 try{
  await page.setViewportSize({width:320,height:900});await page.waitForTimeout(200);
  const overflow=await page.evaluate(()=>document.documentElement.scrollWidth>innerWidth+2);
  await page.evaluate(axe.source);
  const result=await page.evaluate(()=>window.axe.run(document,{runOnly:{type:'tag',values:['wcag2a','wcag2aa','wcag21a','wcag21aa','wcag22aa']}}));
  mobile={overflow,violations:result.violations.length,incomplete:result.incomplete.length,findings:result.violations.map(v=>({help:v.help,description:v.description,tags:v.tags,impact:v.impact,nodes:v.nodes.slice(0,10).map(n=>({selector:n.target,html:n.html,fix:n.failureSummary}))}))};
 }catch(e){mobile={error:'Schmale Darstellung konnte nicht geprüft werden.'};}finally{await page.setViewportSize(desktop);}
 const documents=signals.documentInfo||{};documents.declaredServices=mentionedServices(documents.declaredText||'');delete documents.declaredText;delete signals.documentInfo;
 return {url:page.url(),signals,documents,keyboard:{testedTabs:focus.length,focusedElements:focus.filter(f=>!f.body&&f.visible).length,emptyFocusSteps:focus.filter(f=>f.body||!f.visible).length},reader:{treeAvailable,structuralFindings:accessibility.violations.filter(v=>v.tags.some(t=>['wcag111','wcag131','wcag311','wcag412'].includes(t))).length},mobile};
}
export function buildAutoReview(pages){
 const probes=pages.map(p=>p.reviewProbe).filter(Boolean),count=probes.length;
 const matches=key=>probes.filter(p=>p.signals[key]).map(p=>p.url);
 const signal=(key,found,missing,next)=>make(matches(key).length?'hint':'unknown',count?matches(key).length?found:missing:'Keine auswertbaren Seiten für diesen Prüfversuch.',next,matches(key));
 const r={};
 r.consumer=signal('consumer','Texthinweise auf Angebote für Verbraucher erkannt.','Keine eindeutigen Hinweise auf Verbraucherangebote in den geprüften Seiten erkannt.','Zielgruppe anhand des tatsächlichen Angebots bestätigen.');
 r.contract=signal('contract','Hinweise auf Kauf- oder Buchungsfunktionen erkannt.','Keine eindeutigen Kauf- oder Buchungshinweise im Prüfumfang erkannt.','Den vollständigen Bestell- oder Buchungsablauf fachlich prüfen.');
 r.other=signal('other','Begriffe zu möglicherweise erfassten Dienstleistungen erkannt.','Keine eindeutigen Begriffe zu weiteren erfassten Dienstleistungen erkannt.','Dienstleistungsart prüfen; Textsuche entscheidet keine BFSG-Anwendbarkeit.');
 r.micro=make('unknown','Beschäftigtenzahl, Umsatz und Bilanzsumme sind aus der Website nicht zuverlässig ermittelbar.','Betreiberangaben und geeignete Unternehmensnachweise einholen.');
 r.info=signal('info','Ein Link oder Text zu Barrierefreiheitsinformationen wurde erkannt.','Keine eindeutigen Barrierefreiheitsinformationen im Prüfumfang gefunden.','Inhalt, Vollständigkeit und einschlägige Anforderungen fachlich prüfen.');
 const tabs=probes.reduce((sum,p)=>sum+p.keyboard.testedTabs,0);
 r.keyboard=make(count?'partial':'unknown',count?`${tabs} Tab-Schritte auf ${count} Seiten getestet; ${probes.reduce((s,p)=>s+p.keyboard.focusedElements,0)} Schritte mit sichtbarem fokussiertem Element. Dies bewertet noch keinen sichtbaren Fokusrahmen und keine vollständige Bedienbarkeit.`:'Kein Tastaturtest möglich.','Menüs, Dialoge, Fokusreihenfolge, Fokusfallen und vollständige Formularabläufe manuell prüfen.');
 r.reader=make(count?'partial':'unknown',count?`Zugänglicher Browser-Inhaltsbaum auf ${probes.filter(p=>p.reader.treeAvailable).length} Seiten geprüft; ${probes.reduce((s,p)=>s+p.reader.structuralFindings,0)} strukturelle automatische Befunde. Kein echter Screenreader wurde bedient.`:'Keine strukturelle Prüfung möglich.','Zentrale Abläufe mit einem echten Screenreader testen.');
 const mobileProblems=probes.filter(p=>p.mobile.overflow||p.mobile.violations);
 r.mobile=make(count?'partial':'unknown',count?`Schmale Darstellung mit 320 Pixel Breite auf ${count} Seiten getestet. ${mobileProblems.length} Seiten mit automatischen Befunden oder horizontalem Überlauf; ${probes.filter(p=>p.mobile.error).length} Testfehler.`:'Keine schmale Darstellung geprüft.','Betroffene Seiten sowie Zoom, Textvergrößerung und Gerätebedienung manuell nachprüfen.',mobileProblems.map(p=>p.url));
 r.privacy=signal('privacy','Datenschutz-Link erkannt. Der Inhalt wurde nicht rechtlich abgeglichen.','Kein eindeutiger Datenschutz-Link im Prüfumfang gefunden.','Datenschutzhinweise mit Cookies, externen Diensten und tatsächlichen Datenflüssen abgleichen.');
 const states=pages.flatMap(p=>p.states||[]);
 const clicked=states.filter(s=>s.state!=='initial'&&s.action?.startsWith('Schaltfläche betätigt')).length;
 r.withdraw=make(states.length?'partial':'unknown',states.length?`${clicked} Ablehnungs-/Zustimmungsaktionen ausgeführt. ${matches('withdraw').length} Seiten mit Hinweisen zu Einstellungen oder Widerruf. Widerruf und granulare Auswahl sind nicht funktional bestätigt.`:'Keine Einwilligungszustände auswertbar.','Ablehnung, einzelne Zwecke und nachträglichen Widerruf vollständig testen.',matches('withdraw'));
 r.contracts=signal('contracts','Begriffe zu Rechtsgrundlagen, Verträgen oder Drittlandübermittlungen erkannt.','Keine eindeutigen Hinweise zu diesen Punkten im Prüfumfang erkannt.','Tatsächliche Verträge, Datenflüsse und Rechtsgrundlagen fachlich bewerten.');
 r.imprint=signal('imprint','Impressum-Link erkannt. Inhalt und Betreiberangaben sind fachlich zu bestätigen.','Kein eindeutig benannter Impressum-Link im Prüfumfang erkannt.','Erreichbarkeit, Anbieterkennzeichnung und erforderliche Kontaktangaben prüfen.');
 return r;
}
