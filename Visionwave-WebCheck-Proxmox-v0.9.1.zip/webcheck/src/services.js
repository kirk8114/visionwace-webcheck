const rules=[
 ['Google Analytics',/google-analytics\.com|analytics\.google\.com|googletagmanager\.com\/gtag\/js\?[^\s]*id=(?:G-|UA-)/i],
 ['Google Ads',/googleadservices\.com|doubleclick\.net|googlesyndication\.com|googletagmanager\.com\/gtag\/js\?[^\s]*id=AW-/i],
 ['Google Tag Manager',/googletagmanager\.com\/(?:gtm\.js|ns\.html)/i],
 ['Meta Pixel',/connect\.facebook\.net|facebook\.com\/tr(?:\?|\/|$)/i],
 ['Google Fonts',/fonts\.googleapis\.com|fonts\.gstatic\.com/i],
 ['YouTube',/youtube\.com|youtube-nocookie\.com|ytimg\.com/i],
 ['Google Maps',/maps\.google|google\.com\/maps/i],['reCAPTCHA',/recaptcha/i],
 ['Vimeo',/vimeo\.com/i],['Hotjar',/hotjar\.com/i],['Microsoft Clarity',/clarity\.ms/i],['TikTok Pixel',/analytics\.tiktok\.com/i]
];
export const trackingNames=['Google Analytics','Google Ads','Meta Pixel','Hotjar','Microsoft Clarity','TikTok Pixel'];
export function detectServices(urls){return rules.filter(([,pattern])=>urls.some(url=>pattern.test(url))).map(([name])=>name);}
export function servicesForRequests(requests){return [...new Set([...detectServices(requests.map(r=>r.url)),...requests.flatMap(r=>r.detectedServices||[])])];}
export function mentionedServices(text){
 const aliases={'Google Analytics':/google analytics|ga4/i,'Google Ads':/google ads|google adwords|doubleclick/i,'Google Tag Manager':/google tag manager/i,'Meta Pixel':/meta pixel|facebook pixel/i,'Google Fonts':/google fonts/i,'YouTube':/youtube/i,'Google Maps':/google maps/i,'reCAPTCHA':/recaptcha/i,'Vimeo':/vimeo/i,'Hotjar':/hotjar/i,'Microsoft Clarity':/microsoft clarity/i,'TikTok Pixel':/tiktok/i};
 return Object.entries(aliases).filter(([,re])=>re.test(text)).map(([name])=>name);
}
