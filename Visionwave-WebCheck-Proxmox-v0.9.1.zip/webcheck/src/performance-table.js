export function performanceRows(performance){
 if(!performance?.successfulRuns)return [];
 const n=(v,d=2)=>v.toLocaleString('de-DE',{minimumFractionDigits:d,maximumFractionDigits:d});
 const rows=[];
 const add=(key,label,target,format,good,poor)=>{const value=performance[key];if(!Number.isFinite(value)||value<0)return;const color=good==null?'gray':value<=good?'green':poor!=null&&value>poor?'red':'yellow';rows.push({key,label,target,actual:format(value),color,assessment:color==='gray'?'Messwert':color==='green'?'Ziel erreicht':color==='red'?'Deutlich erhöht':'Optimieren'});};
 add('lcpMs','Hauptinhalt sichtbar (LCP)','≤ 2,50 s',v=>n(v/1000)+' s',2500,4000);
 add('cls','Layoutverschiebung (CLS)','≤ 0,10',v=>n(v,3),.1,.25);
 add('bytes','Datenmenge pro Aufruf','≤ 2,00 MiB*',v=>n(v/1048576)+' MiB',2*1048576);
 add('domMs','Dokumentaufbau (DOM)','Individuell',v=>n(v/1000)+' s');
 add('requests','Anfragen pro Aufruf','Individuell',v=>n(v,0));
 return rows;
}
