@echo off
setlocal
cd /d "%~dp0"
where docker >nul 2>nul
if errorlevel 1 (
 echo Bitte Docker Desktop installieren und starten.
 pause
 exit /b 1
)
docker compose up -d --build
if errorlevel 1 (
 pause
 exit /b 1
)
start "" "http://localhost:3000"
echo WebCheck laeuft. Stoppen mit: docker compose down
pause
